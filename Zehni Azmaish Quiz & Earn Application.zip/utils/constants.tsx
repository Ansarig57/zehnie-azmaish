export const QUIZ_CATEGORIES = [
  { name: 'General Knowledge', icon: 'Brain', color: 'bg-purple-500' },
  { name: 'Islamic', icon: 'Target', color: 'bg-green-500' },
  { name: 'Current Affairs', icon: 'Zap', color: 'bg-blue-500' },
  { name: 'Sports', icon: 'Target', color: 'bg-orange-500' },
  { name: 'Science', icon: 'Brain', color: 'bg-indigo-500' },
  { name: 'History', icon: 'Target', color: 'bg-amber-500' },
  { name: 'Math', icon: 'Brain', color: 'bg-red-500' },
  { name: 'English', icon: 'Target', color: 'bg-pink-500' },
  { name: 'Urdu', icon: 'Brain', color: 'bg-teal-500' }
];

export const QUIZ_DIFFICULTIES = ['Beginner', 'Pro', 'Expert', 'Legend'];

export const WITHDRAWAL_METHODS = [
  { value: 'jazzcash', label: 'JazzCash', icon: 'Smartphone' },
  { value: 'easypaisa', label: 'EasyPaisa', icon: 'Smartphone' },
  { value: 'bank', label: 'Bank Transfer', icon: 'Building2' }
];

export const AVATAR_OPTIONS = [
  '👤', '🧑', '👨', '👩', '🧔', '👱', '🧑‍💻', '🎭', 
  '🦸', '🧙', '👨‍🎓', '👩‍🎓', '🤖', '👽', '🎪', '🎨'
];

export const QUIZ_SCORING = {
  CORRECT_POINTS: 10,
  WRONG_POINTS: -5,
  POINTS_TO_PKR: 100,
  QUESTION_TIME_LIMIT: 10,
  MIN_WITHDRAWAL_AMOUNT: 200
};

export const ACHIEVEMENT_DEFINITIONS = [
  { 
    name: 'Quiz Master', 
    condition: (points) => points >= 1000, 
    icon: '🎓',
    description: 'Earn 1000+ points'
  },
  { 
    name: 'Consistent Player', 
    condition: (streak) => streak >= 7, 
    icon: '🔥',
    description: '7 day login streak'
  },
  { 
    name: 'High Earner', 
    condition: (earnings) => earnings >= 50, 
    icon: '💰',
    description: 'Earn 50+ PKR'
  },
  { 
    name: 'Knowledge Seeker', 
    condition: (points) => points >= 500, 
    icon: '📚',
    description: 'Earn 500+ points'
  }
];