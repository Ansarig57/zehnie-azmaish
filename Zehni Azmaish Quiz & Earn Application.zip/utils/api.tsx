import { supabase } from './supabase/client'
import { projectId, publicAnonKey } from './supabase/info'

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01`

export const apiCall = async (endpoint: string, options: RequestInit = {}) => {
  const { data: { session } } = await supabase.auth.getSession()
  const token = session?.access_token || publicAnonKey
  
  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...options.headers
    }
  })
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Request failed' }))
    throw new Error(error.error || 'Request failed')
  }
  
  return response.json()
}

export const adminApi = {
  getUsers: () => apiCall('/admin/users'),
  updateUserPoints: (userId: string, points: number) => 
    apiCall('/admin/update-user-points', {
      method: 'PUT',
      body: JSON.stringify({ userId, points })
    }),
  getWithdrawals: () => apiCall('/admin/withdrawals'),
  processWithdrawal: (withdrawalId: string, status: string, reason?: string) =>
    apiCall('/admin/process-withdrawal', {
      method: 'PUT',
      body: JSON.stringify({ withdrawalId, status, reason })
    }),
  addQuestion: (questionData: any) =>
    apiCall('/admin/add-question', {
      method: 'POST',
      body: JSON.stringify(questionData)
    }),
  initData: () => apiCall('/init-data', { method: 'POST' })
}

export const userApi = {
  getUserProfile: () => apiCall('/user-profile'),
  updateProfile: (data: any) => apiCall('/update-profile', {
    method: 'PUT',
    body: JSON.stringify(data)
  }),
  dailyLogin: () => apiCall('/daily-login', { method: 'POST' })
}

export const quizApi = {
  getCategories: () => apiCall('/categories'),
  getQuestions: (category: string, difficulty: string) => 
    apiCall(`/questions/${category}/${difficulty}`),
  submitQuiz: (data: any) => apiCall('/submit-quiz', {
    method: 'POST',
    body: JSON.stringify(data)
  })
}

export const walletApi = {
  withdrawRequest: (data: any) => apiCall('/withdraw-request', {
    method: 'POST',
    body: JSON.stringify(data)
  }),
  getWithdrawalHistory: () => apiCall('/withdrawal-history')
}

export const leaderboardApi = {
  getLeaderboard: () => apiCall('/leaderboard')
}