import { supabase } from './supabase/client';
import { projectId } from './supabase/info';

export const adminAPI = {
  async loadUsers() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) {
      throw new Error('No valid session found');
    }
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/admin/users`,
      {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to load users');
    }
    return data.users || [];
  },

  async loadQuestions() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) {
      throw new Error('No valid session found');
    }
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/admin/questions`,
      {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to load questions');
    }
    return data.questions || [];
  },

  async loadWithdrawals() {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) {
      throw new Error('No valid session found');
    }
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/admin/withdrawals`,
      {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to load withdrawals');
    }
    return data.withdrawals || [];
  },

  async updateUserPoints(userId: string, newPoints: number) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) {
      throw new Error('No valid session found');
    }
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/admin/update-user-points`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ userId, points: newPoints })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to update user points');
    }
    return data;
  },

  async addQuestion(question: any) {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) {
      throw new Error('No valid session found');
    }
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/admin/add-question`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(question)
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to add question');
    }
    return data;
  },

  async processWithdrawal(withdrawalId: string, action: string, rejectionReason = '') {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session?.access_token) {
      throw new Error('No valid session found');
    }
    
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/admin/process-withdrawal`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ withdrawalId, action, rejectionReason })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'Failed to process withdrawal');
    }
    return data;
  }
};