import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js'
import * as kv from './kv_store.tsx'

const app = new Hono()

app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*']
}))

app.use('*', logger(console.log))

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
)

// Helper function to verify user authentication
async function verifyUser(request: Request) {
  const accessToken = request.headers.get('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  if (!user?.id) {
    return null;
  }
  return user;
}

// Initialize default admin and sample data
app.post('/make-server-c7e72f01/init', async (c) => {
  try {
    // Create default admin user
    const { data: adminData, error: adminError } = await supabase.auth.admin.createUser({
      email: 'admin@zehniazmish.com',
      password: 'admin123',
      user_metadata: { 
        name: 'Admin User',
        role: 'admin',
        points: 0,
        earnings: 0,
        loginStreak: 0,
        lastLogin: null
      },
      email_confirm: true
    });

    if (adminError && !adminError.message.includes('already registered')) {
      console.log('Admin creation error:', adminError);
    }

    // Create sample user
    const { data: userData, error: userError } = await supabase.auth.admin.createUser({
      email: 'user@test.com',
      password: 'user123',
      user_metadata: { 
        name: 'Test User',
        role: 'user',
        points: 500,
        earnings: 5,
        loginStreak: 3,
        lastLogin: new Date().toISOString()
      },
      email_confirm: true
    });

    if (userError && !userError.message.includes('already registered')) {
      console.log('User creation error:', userError);
    }

    // Initialize sample quiz questions
    await initializeSampleQuestions();
    
    return c.json({ message: 'Application initialized successfully' });
  } catch (error) {
    console.log('Initialization error:', error);
    return c.json({ error: 'Failed to initialize application' }, 500);
  }
});

async function initializeSampleQuestions() {
  const categories = ['General Knowledge', 'Islamic', 'Current Affairs', 'Sports', 'Science', 'History', 'Math', 'English', 'Urdu'];
  const difficulties = ['Beginner', 'Pro', 'Expert', 'Legend'];
  
  // Sample questions for each category and difficulty
  const sampleQuestions = [
    {
      category: 'General Knowledge',
      difficulty: 'Beginner',
      question: 'What is the capital of Pakistan?',
      options: ['Karachi', 'Lahore', 'Islamabad', 'Peshawar'],
      correctAnswer: 2,
      explanation: 'Islamabad is the capital city of Pakistan.'
    },
    {
      category: 'Islamic',
      difficulty: 'Beginner',
      question: 'How many pillars of Islam are there?',
      options: ['3', '4', '5', '6'],
      correctAnswer: 2,
      explanation: 'There are five pillars of Islam: Shahada, Salah, Zakat, Sawm, and Hajj.'
    },
    {
      category: 'Science',
      difficulty: 'Beginner',
      question: 'What is the chemical symbol for water?',
      options: ['H2O', 'CO2', 'NaCl', 'O2'],
      correctAnswer: 0,
      explanation: 'Water is composed of two hydrogen atoms and one oxygen atom, hence H2O.'
    }
  ];

  for (const question of sampleQuestions) {
    const questionKey = `question_${Date.now()}_${Math.random()}`;
    await kv.set(questionKey, question);
  }
}

// User authentication and profile management
app.post('/make-server-c7e72f01/signup', async (c) => {
  try {
    const { email, password, name, phone } = await c.req.json();
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { 
        name,
        phone,
        role: 'user',
        points: 0,
        earnings: 0,
        loginStreak: 0,
        lastLogin: null,
        avatar: 'default'
      },
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ message: 'User created successfully', user: data.user });
  } catch (error) {
    console.log('Signup processing error:', error);
    return c.json({ error: 'Failed to create user' }, 500);
  }
});

app.post('/make-server-c7e72f01/update-profile', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  try {
    const updates = await c.req.json();
    
    const { error } = await supabase.auth.admin.updateUserById(user.id, {
      user_metadata: { ...user.user_metadata, ...updates }
    });

    if (error) {
      console.log('Profile update error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.log('Profile update processing error:', error);
    return c.json({ error: 'Failed to update profile' }, 500);
  }
});

// Quiz question management
app.get('/make-server-c7e72f01/questions/:category/:difficulty', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  try {
    const category = c.req.param('category');
    const difficulty = c.req.param('difficulty');
    
    const questions = await kv.getByPrefix('question_');
    const filteredQuestions = questions
      .filter(q => q.category === category && q.difficulty === difficulty)
      .sort(() => Math.random() - 0.5)
      .slice(0, 10);

    return c.json({ questions: filteredQuestions });
  } catch (error) {
    console.log('Questions fetch error:', error);
    return c.json({ error: 'Failed to fetch questions' }, 500);
  }
});

app.post('/make-server-c7e72f01/submit-quiz', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  try {
    const { answers, questions } = await c.req.json();
    
    let score = 0;
    let correctAnswers = 0;
    
    answers.forEach((answer: number, index: number) => {
      if (answer === questions[index].correctAnswer) {
        score += 10;
        correctAnswers++;
      } else if (answer !== -1) { // -1 means no answer selected
        score -= 5;
      }
    });

    // Update user points
    const newPoints = Math.max(0, (user.user_metadata.points || 0) + score);
    const newEarnings = Math.floor(newPoints / 100);

    await supabase.auth.admin.updateUserById(user.id, {
      user_metadata: { 
        ...user.user_metadata, 
        points: newPoints,
        earnings: newEarnings
      }
    });

    const accuracy = Math.round((correctAnswers / questions.length) * 100);

    return c.json({ 
      score, 
      correctAnswers, 
      totalQuestions: questions.length,
      accuracy,
      newPoints,
      newEarnings
    });
  } catch (error) {
    console.log('Quiz submission error:', error);
    return c.json({ error: 'Failed to submit quiz' }, 500);
  }
});

// Wallet and withdrawal management
app.post('/make-server-c7e72f01/withdraw', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  try {
    const { amount, method, accountDetails } = await c.req.json();
    
    if (amount < 200) {
      return c.json({ error: 'Minimum withdrawal amount is 200 PKR' }, 400);
    }

    const userEarnings = user.user_metadata.earnings || 0;
    if (amount > userEarnings) {
      return c.json({ error: 'Insufficient balance' }, 400);
    }

    const withdrawalId = `withdrawal_${user.id}_${Date.now()}`;
    const withdrawal = {
      id: withdrawalId,
      userId: user.id,
      userName: user.user_metadata.name,
      amount,
      method,
      accountDetails,
      status: 'pending',
      requestDate: new Date().toISOString(),
      processedDate: null,
      rejectionReason: null
    };

    await kv.set(withdrawalId, withdrawal);

    // Deduct amount from user earnings
    const remainingPoints = (user.user_metadata.points || 0) - (amount * 100);
    const remainingEarnings = userEarnings - amount;

    await supabase.auth.admin.updateUserById(user.id, {
      user_metadata: { 
        ...user.user_metadata, 
        points: remainingPoints,
        earnings: remainingEarnings
      }
    });

    return c.json({ message: 'Withdrawal request submitted successfully' });
  } catch (error) {
    console.log('Withdrawal request error:', error);
    return c.json({ error: 'Failed to process withdrawal request' }, 500);
  }
});

app.get('/make-server-c7e72f01/withdrawal-history/:userId', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  try {
    const userId = c.req.param('userId');
    if (userId !== user.id && user.user_metadata.role !== 'admin') {
      return c.json({ error: 'Access denied' }, 403);
    }

    const withdrawals = await kv.getByPrefix('withdrawal_');
    const userWithdrawals = withdrawals
      .filter(w => w.userId === userId)
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime());

    return c.json({ withdrawals: userWithdrawals });
  } catch (error) {
    console.log('Withdrawal history error:', error);
    return c.json({ error: 'Failed to fetch withdrawal history' }, 500);
  }
});

// Leaderboard
app.get('/make-server-c7e72f01/leaderboard', async (c) => {
  try {
    const { data: users, error } = await supabase.auth.admin.listUsers();
    
    if (error) {
      console.log('Leaderboard fetch error:', error);
      return c.json({ error: 'Failed to fetch leaderboard' }, 500);
    }

    const leaderboard = users.users
      .filter(user => user.user_metadata?.role !== 'admin')
      .map(user => ({
        id: user.id,
        name: user.user_metadata?.name || 'Anonymous',
        points: user.user_metadata?.points || 0,
        avatar: user.user_metadata?.avatar || 'default'
      }))
      .sort((a, b) => b.points - a.points)
      .slice(0, 100);

    return c.json({ leaderboard });
  } catch (error) {
    console.log('Leaderboard processing error:', error);
    return c.json({ error: 'Failed to process leaderboard' }, 500);
  }
});

// Daily login bonus
app.post('/make-server-c7e72f01/daily-login', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user) {
    return c.json({ error: 'Unauthorized' }, 401);
  }

  try {
    const today = new Date().toDateString();
    const lastLogin = user.user_metadata.lastLogin ? new Date(user.user_metadata.lastLogin).toDateString() : null;
    
    if (lastLogin === today) {
      return c.json({ message: 'Already claimed today', bonus: 0 });
    }

    const currentStreak = user.user_metadata.loginStreak || 0;
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const isConsecutive = lastLogin === yesterday.toDateString();
    
    const newStreak = isConsecutive ? currentStreak + 1 : 1;
    const bonus = Math.min(50 + (newStreak * 5), 100); // Max 100 points

    const newPoints = (user.user_metadata.points || 0) + bonus;
    const newEarnings = Math.floor(newPoints / 100);

    await supabase.auth.admin.updateUserById(user.id, {
      user_metadata: { 
        ...user.user_metadata, 
        points: newPoints,
        earnings: newEarnings,
        loginStreak: newStreak,
        lastLogin: new Date().toISOString()
      }
    });

    return c.json({ message: 'Daily bonus claimed!', bonus, streak: newStreak });
  } catch (error) {
    console.log('Daily login error:', error);
    return c.json({ error: 'Failed to process daily login' }, 500);
  }
});

// Admin routes
app.get('/make-server-c7e72f01/admin/users', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user || user.user_metadata?.role !== 'admin') {
    return c.json({ error: 'Admin access required' }, 403);
  }

  try {
    const { data: users, error } = await supabase.auth.admin.listUsers();
    
    if (error) {
      console.log('Admin users fetch error:', error);
      return c.json({ error: 'Failed to fetch users' }, 500);
    }

    const userList = users.users.map(user => ({
      id: user.id,
      email: user.email,
      name: user.user_metadata?.name || 'Unknown',
      phone: user.user_metadata?.phone || 'Not provided',
      role: user.user_metadata?.role || 'user',
      points: user.user_metadata?.points || 0,
      earnings: user.user_metadata?.earnings || 0,
      loginStreak: user.user_metadata?.loginStreak || 0,
      lastLogin: user.user_metadata?.lastLogin
    }));

    return c.json({ users: userList });
  } catch (error) {
    console.log('Admin users processing error:', error);
    return c.json({ error: 'Failed to process users list' }, 500);
  }
});

app.post('/make-server-c7e72f01/admin/update-user-points', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user || user.user_metadata?.role !== 'admin') {
    return c.json({ error: 'Admin access required' }, 403);
  }

  try {
    const { userId, points } = await c.req.json();
    
    const { data: targetUser, error: fetchError } = await supabase.auth.admin.getUserById(userId);
    if (fetchError || !targetUser) {
      return c.json({ error: 'User not found' }, 404);
    }

    const newEarnings = Math.floor(points / 100);

    const { error } = await supabase.auth.admin.updateUserById(userId, {
      user_metadata: { 
        ...targetUser.user.user_metadata, 
        points: points,
        earnings: newEarnings
      }
    });

    if (error) {
      console.log('Admin update points error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ message: 'User points updated successfully' });
  } catch (error) {
    console.log('Admin update points processing error:', error);
    return c.json({ error: 'Failed to update user points' }, 500);
  }
});

app.get('/make-server-c7e72f01/admin/withdrawals', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user || user.user_metadata?.role !== 'admin') {
    return c.json({ error: 'Admin access required' }, 403);
  }

  try {
    const withdrawals = await kv.getByPrefix('withdrawal_');
    const sortedWithdrawals = withdrawals.sort((a, b) => 
      new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime()
    );

    return c.json({ withdrawals: sortedWithdrawals });
  } catch (error) {
    console.log('Admin withdrawals error:', error);
    return c.json({ error: 'Failed to fetch withdrawals' }, 500);
  }
});

app.post('/make-server-c7e72f01/admin/process-withdrawal', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user || user.user_metadata?.role !== 'admin') {
    return c.json({ error: 'Admin access required' }, 403);
  }

  try {
    const { withdrawalId, action, rejectionReason } = await c.req.json();
    
    const withdrawal = await kv.get(withdrawalId);
    if (!withdrawal) {
      return c.json({ error: 'Withdrawal not found' }, 404);
    }

    withdrawal.status = action;
    withdrawal.processedDate = new Date().toISOString();
    
    if (action === 'rejected') {
      withdrawal.rejectionReason = rejectionReason;
      
      // Refund points to user
      const { data: targetUser, error: fetchError } = await supabase.auth.admin.getUserById(withdrawal.userId);
      if (!fetchError && targetUser) {
        const refundPoints = (targetUser.user.user_metadata.points || 0) + (withdrawal.amount * 100);
        const refundEarnings = (targetUser.user.user_metadata.earnings || 0) + withdrawal.amount;

        await supabase.auth.admin.updateUserById(withdrawal.userId, {
          user_metadata: { 
            ...targetUser.user.user_metadata, 
            points: refundPoints,
            earnings: refundEarnings
          }
        });
      }
    }

    await kv.set(withdrawalId, withdrawal);

    return c.json({ message: `Withdrawal ${action} successfully` });
  } catch (error) {
    console.log('Admin process withdrawal error:', error);
    return c.json({ error: 'Failed to process withdrawal' }, 500);
  }
});

app.post('/make-server-c7e72f01/admin/add-question', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user || user.user_metadata?.role !== 'admin') {
    return c.json({ error: 'Admin access required' }, 403);
  }

  try {
    const question = await c.req.json();
    const questionId = `question_${Date.now()}_${Math.random()}`;
    
    await kv.set(questionId, question);

    return c.json({ message: 'Question added successfully' });
  } catch (error) {
    console.log('Admin add question error:', error);
    return c.json({ error: 'Failed to add question' }, 500);
  }
});

app.get('/make-server-c7e72f01/admin/questions', async (c) => {
  const user = await verifyUser(c.req.raw);
  if (!user || user.user_metadata?.role !== 'admin') {
    return c.json({ error: 'Admin access required' }, 403);
  }

  try {
    const questions = await kv.getByPrefix('question_');
    return c.json({ questions });
  } catch (error) {
    console.log('Admin questions fetch error:', error);
    return c.json({ error: 'Failed to fetch questions' }, 500);
  }
});

Deno.serve(app.fetch)