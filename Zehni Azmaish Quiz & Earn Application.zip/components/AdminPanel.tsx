import React, { useState, useEffect } from 'react';
import { Card, CardContent } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { adminAPI } from '../utils/adminHelpers';
import { AdminUsers } from './admin/AdminUsers';
import { AdminQuestions } from './admin/AdminQuestions';
import { AdminWithdrawals } from './admin/AdminWithdrawals';
import { Users, Brain, CreditCard, DollarSign, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface AdminPanelProps {
  user: any;
}

export function AdminPanel({ user }: AdminPanelProps) {
  const [users, setUsers] = useState([]);
  const [questions, setQuestions] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('users');

  useEffect(() => {
    loadData();
  }, [activeTab]);

  const loadData = async () => {
    setLoading(true);
    try {
      if (activeTab === 'users') {
        const userData = await adminAPI.loadUsers();
        setUsers(userData);
      } else if (activeTab === 'questions') {
        const questionData = await adminAPI.loadQuestions();
        setQuestions(questionData);
      } else if (activeTab === 'withdrawals') {
        const withdrawalData = await adminAPI.loadWithdrawals();
        setWithdrawals(withdrawalData);
      }
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateUserPoints = async (userId: string, points: number) => {
    try {
      await adminAPI.updateUserPoints(userId, points);
      toast.success('User points updated successfully');
      loadData();
    } catch (error: any) {
      console.error('Failed to update user points:', error);
      toast.error(error.message || 'Failed to update user points');
    }
  };

  const handleAddQuestion = async (question: any) => {
    try {
      await adminAPI.addQuestion(question);
      loadData();
    } catch (error: any) {
      console.error('Failed to add question:', error);
      toast.error(error.message || 'Failed to add question');
    }
  };

  const handleProcessWithdrawal = async (withdrawalId: string, action: string, rejectionReason = '') => {
    try {
      await adminAPI.processWithdrawal(withdrawalId, action, rejectionReason);
      loadData();
    } catch (error: any) {
      console.error('Failed to process withdrawal:', error);
      toast.error(error.message || 'Failed to process withdrawal');
    }
  };

  if (user?.user_metadata?.role !== 'admin') {
    return (
      <div className="text-center text-white">
        <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-red-400" />
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-white/70">You don't have permission to access the admin panel.</p>
      </div>
    );
  }

  const pendingWithdrawals = withdrawals.filter((w: any) => w.status === 'pending').length;
  const totalPaid = withdrawals.reduce((sum: number, w: any) => w.status === 'approved' ? sum + w.amount : sum, 0);

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">⚙️ Admin Panel</h1>
        <p className="text-white/70">Manage users, questions, and withdrawal requests</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <Users className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">{users.length}</div>
            <div className="text-sm text-white/70">Total Users</div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <Brain className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">{questions.length}</div>
            <div className="text-sm text-white/70">Questions</div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <CreditCard className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">{pendingWithdrawals}</div>
            <div className="text-sm text-white/70">Pending Withdrawals</div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <DollarSign className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">{totalPaid} PKR</div>
            <div className="text-sm text-white/70">Total Paid</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 bg-white/10">
          <TabsTrigger value="users" className="text-white data-[state=active]:bg-white/20">
            <Users className="w-4 h-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="questions" className="text-white data-[state=active]:bg-white/20">
            <Brain className="w-4 h-4 mr-2" />
            Questions
          </TabsTrigger>
          <TabsTrigger value="withdrawals" className="text-white data-[state=active]:bg-white/20">
            <CreditCard className="w-4 h-4 mr-2" />
            Withdrawals
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-6">
          {loading ? (
            <div className="text-center text-white">Loading...</div>
          ) : (
            <AdminUsers 
              users={users} 
              onUpdateUserPoints={handleUpdateUserPoints}
            />
          )}
        </TabsContent>

        <TabsContent value="questions" className="space-y-6">
          {loading ? (
            <div className="text-center text-white">Loading...</div>
          ) : (
            <AdminQuestions 
              questions={questions} 
              onAddQuestion={handleAddQuestion}
            />
          )}
        </TabsContent>

        <TabsContent value="withdrawals" className="space-y-6">
          {loading ? (
            <div className="text-center text-white">Loading...</div>
          ) : (
            <AdminWithdrawals 
              withdrawals={withdrawals} 
              onProcessWithdrawal={handleProcessWithdrawal}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}