import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Brain, Wallet, Trophy, Zap, Target, TrendingUp, Star, Calendar, Gift } from 'lucide-react';

interface DashboardProps {
  user: any;
  onNavigate: (page: string) => void;
}

export function Dashboard({ user, onNavigate }: DashboardProps) {
  const points = user?.user_metadata?.points || 0;
  const earnings = user?.user_metadata?.earnings || 0;
  const loginStreak = user?.user_metadata?.loginStreak || 0;
  const name = user?.user_metadata?.name || 'User';

  const stats = [
    {
      title: 'Total Points',
      value: points.toLocaleString(),
      icon: Zap,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-400/10'
    },
    {
      title: 'Earnings (PKR)',
      value: earnings.toLocaleString(),
      icon: Wallet,
      color: 'text-green-400',
      bgColor: 'bg-green-400/10'
    },
    {
      title: 'Login Streak',
      value: `${loginStreak} days`,
      icon: Calendar,
      color: 'text-blue-400',
      bgColor: 'bg-blue-400/10'
    }
  ];

  const categories = [
    { name: 'General Knowledge', icon: Brain, color: 'bg-purple-500' },
    { name: 'Islamic', icon: Star, color: 'bg-green-500' },
    { name: 'Current Affairs', icon: TrendingUp, color: 'bg-blue-500' },
    { name: 'Sports', icon: Target, color: 'bg-orange-500' },
    { name: 'Science', icon: Zap, color: 'bg-indigo-500' },
    { name: 'History', icon: Calendar, color: 'bg-amber-500' },
    { name: 'Math', icon: Target, color: 'bg-red-500' },
    { name: 'English', icon: Brain, color: 'bg-pink-500' },
    { name: 'Urdu', icon: Star, color: 'bg-teal-500' }
  ];

  const achievements = [
    { name: 'First Quiz', completed: points > 0, description: 'Complete your first quiz' },
    { name: 'Point Collector', completed: points >= 100, description: 'Earn 100 points' },
    { name: 'Consistent Player', completed: loginStreak >= 3, description: '3 day login streak' },
    { name: 'High Earner', completed: earnings >= 5, description: 'Earn 5 PKR' }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">
          Welcome back, {name}! 👋
        </h1>
        <p className="text-white/70">
          Ready to test your knowledge and earn rewards?
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="bg-white/10 backdrop-blur-md border-white/20 text-white">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                  <div>
                    <p className="text-sm text-white/70">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Gift className="w-5 h-5" />
            <span>Quick Actions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button 
              onClick={() => onNavigate('quiz')}
              className="h-20 flex flex-col items-center justify-center space-y-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Brain className="w-6 h-6" />
              <span className="text-sm">Start Quiz</span>
            </Button>
            <Button 
              onClick={() => onNavigate('wallet')}
              className="h-20 flex flex-col items-center justify-center space-y-2 bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
            >
              <Wallet className="w-6 h-6" />
              <span className="text-sm">Wallet</span>
            </Button>
            <Button 
              onClick={() => onNavigate('leaderboard')}
              className="h-20 flex flex-col items-center justify-center space-y-2 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700"
            >
              <Trophy className="w-6 h-6" />
              <span className="text-sm">Leaderboard</span>
            </Button>
            <Button 
              onClick={() => onNavigate('profile')}
              className="h-20 flex flex-col items-center justify-center space-y-2 bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-700 hover:to-purple-700"
            >
              <Star className="w-6 h-6" />
              <span className="text-sm">Profile</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Quiz Categories</CardTitle>
          <CardDescription className="text-white/70">
            Choose a category to start your quiz journey
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4">
            {categories.map((category, index) => {
              const Icon = category.icon;
              return (
                <div
                  key={index}
                  className="p-4 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 transition-colors cursor-pointer"
                  onClick={() => onNavigate('quiz')}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-lg ${category.color}`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-medium">{category.name}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Achievements</CardTitle>
          <CardDescription className="text-white/70">
            Track your progress and unlock rewards
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border ${
                  achievement.completed 
                    ? 'bg-green-500/10 border-green-500/30' 
                    : 'bg-white/5 border-white/10'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{achievement.name}</span>
                      {achievement.completed && (
                        <Badge className="bg-green-500 text-white">
                          ✓ Complete
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-white/70 mt-1">
                      {achievement.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}