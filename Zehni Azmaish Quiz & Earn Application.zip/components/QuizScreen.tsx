import React, { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from './ui/card'
import { Button } from './ui/button'
import { Progress } from './ui/progress'
import { Clock, Zap, Trophy, Brain, CheckCircle, XCircle } from 'lucide-react'
import { useAuth } from './AuthContext'
import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from '../utils/supabase/info'

interface Question {
  id: string
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
}

interface QuizScreenProps {
  category: string
  difficulty: string
  onComplete: () => void
}

export function QuizScreen({ category, difficulty, onComplete }: QuizScreenProps) {
  const { user, refreshUser } = useAuth()
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [timeLeft, setTimeLeft] = useState(10)
  const [score, setScore] = useState(0)
  const [answers, setAnswers] = useState<Array<{questionId: string, selectedAnswer: number, isCorrect: boolean}>>([])
  const [showResult, setShowResult] = useState(false)
  const [quizComplete, setQuizComplete] = useState(false)
  const [loading, setLoading] = useState(true)
  const [lifeline5050Used, setLifeline5050Used] = useState(false)
  const [eliminatedOptions, setEliminatedOptions] = useState<number[]>([])
  const [quizResults, setQuizResults] = useState<any>(null)

  const supabase = createClient(
    `https://${projectId}.supabase.co`,
    publicAnonKey
  )

  useEffect(() => {
    fetchQuestions()
  }, [category, difficulty])

  useEffect(() => {
    if (!quizComplete && questions.length > 0) {
      const timer = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleAnswerSubmit()
            return 10
          }
          return prev - 1
        })
      }, 1000)

      return () => clearInterval(timer)
    }
  }, [currentQuestionIndex, quizComplete, questions.length])

  const fetchQuestions = async () => {
    try {
      if (category === 'AI' && difficulty === 'Endless') {
        // For AI quiz, generate questions using Gemini AI
        await generateAIQuestions()
      } else {
        const { data: { session } } = await supabase.auth.getSession()
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/questions/${category}/${difficulty}`, {
          headers: {
            'Authorization': `Bearer ${session?.access_token || publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        })
        
        if (response.ok) {
          const data = await response.json()
          setQuestions(data.questions)
        }
      }
    } catch (error) {
      console.error('Error fetching questions:', error)
    } finally {
      setLoading(false)
    }
  }

  const generateAIQuestions = async () => {
    // Mock AI questions for demo purposes
    const aiQuestions: Question[] = [
      {
        id: 'ai-1',
        question: "What is the largest planet in our solar system?",
        options: ["Earth", "Jupiter", "Saturn", "Neptune"],
        correctAnswer: 1,
        explanation: "Jupiter is the largest planet in our solar system."
      },
      {
        id: 'ai-2',
        question: "Who painted the Mona Lisa?",
        options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
        correctAnswer: 2,
        explanation: "Leonardo da Vinci painted the famous Mona Lisa."
      },
      {
        id: 'ai-3',
        question: "What is the chemical symbol for gold?",
        options: ["Go", "Gd", "Au", "Ag"],
        correctAnswer: 2,
        explanation: "Au is the chemical symbol for gold, derived from the Latin word 'aurum'."
      }
    ]
    setQuestions(aiQuestions)
  }

  const use5050Lifeline = () => {
    if (lifeline5050Used || !questions[currentQuestionIndex]) return
    
    const currentQuestion = questions[currentQuestionIndex]
    const correctAnswer = currentQuestion.correctAnswer
    const incorrectOptions = [0, 1, 2, 3].filter(i => i !== correctAnswer)
    
    // Randomly select 2 incorrect options to eliminate
    const toEliminate = incorrectOptions.sort(() => Math.random() - 0.5).slice(0, 2)
    setEliminatedOptions(toEliminate)
    setLifeline5050Used(true)
  }

  const handleAnswerSubmit = async () => {
    if (!questions[currentQuestionIndex]) return

    const currentQuestion = questions[currentQuestionIndex]
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer
    
    setAnswers(prev => [...prev, {
      questionId: currentQuestion.id,
      selectedAnswer: selectedAnswer ?? -1,
      isCorrect
    }])

    setShowResult(true)
    
    // Show result for 2 seconds, then move to next question
    setTimeout(() => {
      setShowResult(false)
      setSelectedAnswer(null)
      setEliminatedOptions([])
      setTimeLeft(10)
      
      if (currentQuestionIndex < questions.length - 1) {
        setCurrentQuestionIndex(prev => prev + 1)
      } else {
        completeQuiz()
      }
    }, 2000)
  }

  const completeQuiz = async () => {
    setQuizComplete(true)
    
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/submit-quiz`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          answers,
          category,
          difficulty,
          totalQuestions: questions.length
        })
      })
      
      if (response.ok) {
        const results = await response.json()
        setQuizResults(results)
        await refreshUser()
      }
    } catch (error) {
      console.error('Error submitting quiz:', error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-center">
          <Brain className="w-12 h-12 text-purple-400 animate-pulse mx-auto mb-4" />
          <p className="text-white">Loading questions...</p>
        </div>
      </div>
    )
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 max-w-md w-full">
          <CardContent className="p-6 text-center">
            <XCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
            <h2 className="text-xl text-white mb-2">No Questions Available</h2>
            <p className="text-purple-200 mb-4">
              There are no questions available for {category} - {difficulty} level.
            </p>
            <Button onClick={onComplete} className="bg-purple-600 hover:bg-purple-700 text-white">
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (quizComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center p-4">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 max-w-md w-full">
          <CardHeader>
            <CardTitle className="text-center text-white flex items-center justify-center space-x-2">
              <Trophy className="w-6 h-6 text-yellow-400" />
              <span>Quiz Complete!</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            {quizResults && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white/10 rounded-lg p-4">
                    <p className="text-purple-200 text-sm">Score</p>
                    <p className="text-white text-2xl">{quizResults.score}</p>
                  </div>
                  <div className="bg-white/10 rounded-lg p-4">
                    <p className="text-purple-200 text-sm">Accuracy</p>
                    <p className="text-white text-2xl">{quizResults.accuracy.toFixed(1)}%</p>
                  </div>
                </div>
                
                <div className="bg-white/10 rounded-lg p-4">
                  <p className="text-purple-200 text-sm">Correct Answers</p>
                  <p className="text-white text-xl">
                    {quizResults.correctAnswers} / {quizResults.totalQuestions}
                  </p>
                </div>

                <div className="bg-white/10 rounded-lg p-4">
                  <p className="text-purple-200 text-sm">Points Earned</p>
                  <p className="text-green-400 text-xl">+{Math.max(0, quizResults.score)}</p>
                </div>

                {quizResults.unlockedNextLevel && (
                  <div className="bg-yellow-500/20 border border-yellow-400 rounded-lg p-4">
                    <div className="flex items-center justify-center space-x-2">
                      <Star className="w-5 h-5 text-yellow-400" />
                      <p className="text-yellow-400">Next level unlocked!</p>
                    </div>
                  </div>
                )}
              </>
            )}
            
            <div className="space-y-2">
              <Button 
                onClick={onComplete}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                Back to Dashboard
              </Button>
              <Button 
                onClick={() => window.location.reload()}
                variant="outline"
                className="w-full border-white/20 text-white hover:bg-white/10"
              >
                Play Again
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  const currentQuestion = questions[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-white text-xl">{category}</h1>
          <p className="text-purple-200">{difficulty} Level</p>
        </div>
        <div className="text-right">
          <div className="flex items-center space-x-2 text-white">
            <Clock className="w-5 h-5" />
            <span className="text-xl">{timeLeft}s</span>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div className="mb-6">
        <div className="flex justify-between text-white text-sm mb-2">
          <span>Question {currentQuestionIndex + 1} of {questions.length}</span>
          <span>Score: {score}</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Lifeline */}
      {!lifeline5050Used && !showResult && (
        <div className="mb-4">
          <Button
            onClick={use5050Lifeline}
            className="bg-yellow-600 hover:bg-yellow-700 text-white"
          >
            <Zap className="w-4 h-4 mr-2" />
            50:50 Lifeline
          </Button>
        </div>
      )}

      {/* Question Card */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white text-lg">
            {currentQuestion.question}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => {
              const isEliminated = eliminatedOptions.includes(index)
              const isSelected = selectedAnswer === index
              const isCorrect = index === currentQuestion.correctAnswer
              
              let buttonClass = "w-full p-4 text-left border-2 transition-all "
              
              if (showResult) {
                if (isCorrect) {
                  buttonClass += "bg-green-500/30 border-green-400 text-white"
                } else if (isSelected && !isCorrect) {
                  buttonClass += "bg-red-500/30 border-red-400 text-white"
                } else {
                  buttonClass += "bg-white/10 border-white/20 text-gray-300"
                }
              } else if (isSelected) {
                buttonClass += "bg-purple-500/30 border-purple-400 text-white"
              } else if (isEliminated) {
                buttonClass += "bg-gray-500/20 border-gray-500 text-gray-500 opacity-50"
              } else {
                buttonClass += "bg-white/10 border-white/20 text-white hover:bg-white/20"
              }

              return (
                <Button
                  key={index}
                  onClick={() => !showResult && !isEliminated && setSelectedAnswer(index)}
                  disabled={showResult || isEliminated}
                  className={buttonClass}
                >
                  <div className="flex items-center space-x-3">
                    <span className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center text-sm">
                      {String.fromCharCode(65 + index)}
                    </span>
                    <span>{option}</span>
                    {showResult && isCorrect && <CheckCircle className="w-5 h-5 text-green-400 ml-auto" />}
                    {showResult && isSelected && !isCorrect && <XCircle className="w-5 h-5 text-red-400 ml-auto" />}
                  </div>
                </Button>
              )
            })}
          </div>

          {showResult && (
            <div className="mt-4 p-4 bg-white/10 rounded-lg">
              <p className="text-purple-200 text-sm mb-2">Explanation:</p>
              <p className="text-white text-sm">{currentQuestion.explanation}</p>
            </div>
          )}

          {selectedAnswer !== null && !showResult && (
            <Button
              onClick={handleAnswerSubmit}
              className="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white"
            >
              Submit Answer
            </Button>
          )}
        </CardContent>
      </Card>
    </div>
  )
}