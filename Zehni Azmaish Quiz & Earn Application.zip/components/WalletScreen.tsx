import React, { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from './ui/card'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select'
import { ArrowLeft, Wallet, DollarSign, Clock, CheckCircle, XCircle, TrendingUp } from 'lucide-react'
import { useAuth } from './AuthContext'
import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from '../utils/supabase/info'

interface WithdrawalRequest {
  id: string
  amount: number
  method: string
  accountDetails: string
  status: 'pending' | 'approved' | 'rejected'
  requestDate: string
  processedDate?: string
  reason?: string
}

interface WalletScreenProps {
  onBack: () => void
}

export function WalletScreen({ onBack }: WalletScreenProps) {
  const { user, refreshUser } = useAuth()
  const [showWithdrawForm, setShowWithdrawForm] = useState(false)
  const [withdrawalHistory, setWithdrawalHistory] = useState<WithdrawalRequest[]>([])
  const [loading, setLoading] = useState(false)
  
  const [withdrawForm, setWithdrawForm] = useState({
    amount: '',
    method: '',
    accountDetails: ''
  })

  const supabase = createClient(
    `https://${projectId}.supabase.co`,
    publicAnonKey
  )

  useEffect(() => {
    fetchWithdrawalHistory()
  }, [])

  const fetchWithdrawalHistory = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/withdrawal-history`, {
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json'
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        setWithdrawalHistory(data.withdrawals)
      }
    } catch (error) {
      console.error('Error fetching withdrawal history:', error)
    }
  }

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const { data: { session } } = await supabase.auth.getSession()
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/withdraw-request`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount: parseInt(withdrawForm.amount),
          method: withdrawForm.method,
          accountDetails: withdrawForm.accountDetails
        })
      })
      
      if (response.ok) {
        setShowWithdrawForm(false)
        setWithdrawForm({ amount: '', method: '', accountDetails: '' })
        await fetchWithdrawalHistory()
        await refreshUser()
      } else {
        const error = await response.json()
        alert(error.error || 'Withdrawal request failed')
      }
    } catch (error) {
      console.error('Error submitting withdrawal:', error)
      alert('An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-500" />
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-500" />
      default:
        return <Clock className="w-5 h-5 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'text-yellow-500'
      case 'approved': return 'text-green-500'
      case 'rejected': return 'text-red-500'
      default: return 'text-gray-500'
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl text-white">My Wallet</h1>
        </div>
        <Wallet className="w-8 h-8 text-purple-400" />
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-1 gap-4 mb-6">
        <Card className="bg-gradient-to-r from-green-600 to-emerald-600 border-green-400">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm mb-1">Total Earnings</p>
                <p className="text-white text-3xl">₨{user.totalEarnings.toLocaleString()}</p>
                <p className="text-green-100 text-sm mt-1">
                  {user.points.toLocaleString()} points
                </p>
              </div>
              <DollarSign className="w-12 h-12 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 text-sm">Conversion Rate</p>
                <p className="text-white text-lg">100 Points = ₨1</p>
              </div>
              <TrendingUp className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Withdraw Button */}
      {!showWithdrawForm && (
        <Button
          onClick={() => setShowWithdrawForm(true)}
          disabled={user.totalEarnings < 200}
          className="w-full bg-purple-600 hover:bg-purple-700 text-white mb-6 p-4 text-lg"
        >
          {user.totalEarnings < 200 
            ? `Minimum ₨200 required (₨${200 - user.totalEarnings} more needed)`
            : 'Request Withdrawal'
          }
        </Button>
      )}

      {/* Withdrawal Form */}
      {showWithdrawForm && (
        <Card className="bg-white/10 backdrop-blur-md border-white/20 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Withdrawal Request</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleWithdrawSubmit} className="space-y-4">
              <div>
                <Label htmlFor="amount" className="text-white">Amount (PKR)</Label>
                <Input
                  id="amount"
                  type="number"
                  min="200"
                  max={user.totalEarnings}
                  placeholder="Enter amount"
                  value={withdrawForm.amount}
                  onChange={(e) => setWithdrawForm(prev => ({ ...prev, amount: e.target.value }))}
                  required
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-300"
                />
                <p className="text-purple-200 text-sm mt-1">
                  Minimum: ₨200 | Available: ₨{user.totalEarnings}
                </p>
              </div>

              <div>
                <Label htmlFor="method" className="text-white">Payment Method</Label>
                <Select 
                  value={withdrawForm.method} 
                  onValueChange={(value) => setWithdrawForm(prev => ({ ...prev, method: value }))}
                >
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue placeholder="Select payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="jazzcash">JazzCash</SelectItem>
                    <SelectItem value="easypaisa">EasyPaisa</SelectItem>
                    <SelectItem value="bank">Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="account" className="text-white">Account Details</Label>
                <Input
                  id="account"
                  type="text"
                  placeholder="Enter account number/IBAN"
                  value={withdrawForm.accountDetails}
                  onChange={(e) => setWithdrawForm(prev => ({ ...prev, accountDetails: e.target.value }))}
                  required
                  className="bg-white/10 border-white/20 text-white placeholder:text-gray-300"
                />
                <p className="text-purple-200 text-sm mt-1">
                  Enter your {withdrawForm.method === 'bank' ? 'IBAN' : 'mobile number'}
                </p>
              </div>

              <div className="flex space-x-3">
                <Button
                  type="submit"
                  disabled={loading}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  {loading ? 'Processing...' : 'Submit Request'}
                </Button>
                <Button
                  type="button"
                  onClick={() => setShowWithdrawForm(false)}
                  variant="outline"
                  className="flex-1 border-white/20 text-white hover:bg-white/10"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Withdrawal History */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white">Withdrawal History</CardTitle>
        </CardHeader>
        <CardContent>
          {withdrawalHistory.length === 0 ? (
            <p className="text-purple-200 text-center py-8">No withdrawal requests yet</p>
          ) : (
            <div className="space-y-3">
              {withdrawalHistory.map((withdrawal) => (
                <div
                  key={withdrawal.id}
                  className="flex items-center justify-between p-4 bg-white/5 rounded-lg"
                >
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(withdrawal.status)}
                    <div>
                      <p className="text-white">₨{withdrawal.amount}</p>
                      <p className="text-purple-200 text-sm">
                        {withdrawal.method.toUpperCase()} • {new Date(withdrawal.requestDate).toLocaleDateString()}
                      </p>
                      {withdrawal.reason && (
                        <p className="text-red-400 text-xs mt-1">{withdrawal.reason}</p>
                      )}
                    </div>
                  </div>
                  <span className={`text-sm capitalize ${getStatusColor(withdrawal.status)}`}>
                    {withdrawal.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}