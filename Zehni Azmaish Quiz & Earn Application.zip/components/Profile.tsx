import React, { useState } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { projectId } from "../utils/supabase/info";
import { supabase } from "../utils/supabase/client";
import {
  User,
  Mail,
  Phone,
  Edit,
  Save,
  X,
  Shield,
  Calendar,
  Trophy,
  Zap,
  Target,
} from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ProfileProps {
  user: any;
  onLogout: () => void;
}

export function Profile({ user, onLogout }: ProfileProps) {
  const [editing, setEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.user_metadata?.name || "",
    phone: user?.user_metadata?.phone || "",
    avatar: user?.user_metadata?.avatar || "default",
  });

  const points = user?.user_metadata?.points || 0;
  const earnings = user?.user_metadata?.earnings || 0;
  const loginStreak = user?.user_metadata?.loginStreak || 0;
  const role = user?.user_metadata?.role || "user";
  const lastLogin = user?.user_metadata?.lastLogin;

  const avatarOptions = [
    "👤",
    "🧑",
    "👨",
    "👩",
    "🧔",
    "👱",
    "🧑‍💻",
    "🎭",
    "🦸",
    "🧙",
    "👨‍🎓",
    "👩‍🎓",
    "🤖",
    "👽",
    "🎪",
    "🎨",
  ];

  const handleSave = async () => {
    setLoading(true);
    try {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/update-profile`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        },
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error);
      }

      toast.success("Profile updated successfully!");
      setEditing(false);

      // Refresh the page to update user data
      setTimeout(() => window.location.reload(), 1000);
    } catch (error) {
      console.error("Profile update failed:", error);
      toast.error(error.message || "Failed to update profile");
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      name: user?.user_metadata?.name || "",
      phone: user?.user_metadata?.phone || "",
      avatar: user?.user_metadata?.avatar || "default",
    });
    setEditing(false);
  };

  const getAvatarDisplay = () => {
    if (formData.avatar === "default") {
      return (
        user?.user_metadata?.name?.charAt(0).toUpperCase() ||
        "U"
      );
    }
    return formData.avatar;
  };

  const getAvatarColor = (name) => {
    const colors = [
      "bg-red-500",
      "bg-blue-500",
      "bg-green-500",
      "bg-yellow-500",
      "bg-purple-500",
      "bg-pink-500",
      "bg-indigo-500",
      "bg-teal-500",
    ];
    const index = name?.charCodeAt(0) % colors.length || 0;
    return colors[index];
  };

  const achievements = [
    {
      name: "Quiz Master",
      condition: points >= 1000,
      icon: "🎓",
      description: "Earn 1000+ points",
    },
    {
      name: "Consistent Player",
      condition: loginStreak >= 7,
      icon: "🔥",
      description: "7 day login streak",
    },
    {
      name: "High Earner",
      condition: earnings >= 50,
      icon: "💰",
      description: "Earn 50+ PKR",
    },
    {
      name: "Knowledge Seeker",
      condition: points >= 500,
      icon: "📚",
      description: "Earn 500+ points",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">
          👤 My Profile
        </h1>
        <p className="text-white/70">
          Manage your account settings and view achievements
        </p>
      </div>

      {/* Profile Information */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription className="text-white/70">
              Update your personal information
            </CardDescription>
          </div>
          {!editing ? (
            <Button
              variant="outline"
              size="sm"
              onClick={() => setEditing(true)}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
            >
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
          ) : (
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleCancel}
                className="bg-red-500/20 border-red-500/30 text-red-300 hover:bg-red-500/30"
              >
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleSave}
                disabled={loading}
                className="bg-green-600 hover:bg-green-700"
              >
                <Save className="w-4 h-4 mr-2" />
                {loading ? "Saving..." : "Save"}
              </Button>
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
            <div className="flex flex-col items-center space-y-4">
              <Avatar className="w-24 h-24">
                <AvatarFallback
                  className={`${getAvatarColor(user?.user_metadata?.name)} text-white text-2xl`}
                >
                  {getAvatarDisplay()}
                </AvatarFallback>
              </Avatar>

              {editing && (
                <div className="grid grid-cols-4 gap-2">
                  {avatarOptions.map((emoji, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className={`
                        w-10 h-10 p-0 bg-white/10 border-white/20 hover:bg-white/20
                        ${formData.avatar === emoji ? "ring-2 ring-blue-500" : ""}
                      `}
                      onClick={() =>
                        setFormData({
                          ...formData,
                          avatar: emoji,
                        })
                      }
                    >
                      {emoji}
                    </Button>
                  ))}
                </div>
              )}
            </div>

            <div className="flex-1 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label
                    htmlFor="name"
                    className="flex items-center space-x-2"
                  >
                    <User className="w-4 h-4" />
                    <span>Full Name</span>
                  </Label>
                  {editing ? (
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          name: e.target.value,
                        })
                      }
                      className="bg-white/10 border-white/20 text-white"
                    />
                  ) : (
                    <div className="p-3 bg-white/5 rounded-lg">
                      {user?.user_metadata?.name || "Not set"}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label
                    htmlFor="email"
                    className="flex items-center space-x-2"
                  >
                    <Mail className="w-4 h-4" />
                    <span>Email</span>
                  </Label>
                  <div className="p-3 bg-white/5 rounded-lg opacity-50">
                    {user?.email} (Cannot be changed)
                  </div>
                </div>

                <div className="space-y-2">
                  <Label
                    htmlFor="phone"
                    className="flex items-center space-x-2"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Phone Number</span>
                  </Label>
                  {editing ? (
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          phone: e.target.value,
                        })
                      }
                      className="bg-white/10 border-white/20 text-white"
                      placeholder="+92XXXXXXXXXX"
                    />
                  ) : (
                    <div className="p-3 bg-white/5 rounded-lg">
                      {user?.user_metadata?.phone || "Not set"}
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label className="flex items-center space-x-2">
                    <Shield className="w-4 h-4" />
                    <span>Role</span>
                  </Label>
                  <div className="p-3 bg-white/5 rounded-lg">
                    <Badge
                      className={
                        role === "admin"
                          ? "bg-red-500"
                          : "bg-blue-500"
                      }
                    >
                      {role.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {points.toLocaleString()}
              </div>
              <div className="text-sm text-white/70">
                Total Points
              </div>
            </div>
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <Trophy className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {earnings}
              </div>
              <div className="text-sm text-white/70">
                Earnings (PKR)
              </div>
            </div>
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <Target className="w-8 h-8 text-blue-400 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {loginStreak}
              </div>
              <div className="text-sm text-white/70">
                Login Streak
              </div>
            </div>
            <div className="text-center p-4 bg-white/5 rounded-lg">
              <Calendar className="w-8 h-8 text-purple-400 mx-auto mb-2" />
              <div className="text-sm font-bold">
                {lastLogin
                  ? new Date(lastLogin).toLocaleDateString()
                  : "Never"}
              </div>
              <div className="text-sm text-white/70">
                Last Login
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Achievements */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>🏆 Achievements</CardTitle>
          <CardDescription className="text-white/70">
            Track your progress and unlock rewards
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className={`
                  p-4 rounded-lg border transition-colors
                  ${
                    achievement.condition
                      ? "bg-green-500/10 border-green-500/30"
                      : "bg-white/5 border-white/10"
                  }
                `}
              >
                <div className="flex items-center space-x-3">
                  <div className="text-2xl">
                    {achievement.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">
                        {achievement.name}
                      </span>
                      {achievement.condition && (
                        <Badge className="bg-green-500 text-white text-xs">
                          ✓ Unlocked
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-white/70">
                      {achievement.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Account Actions */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle>Account Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <Button
              onClick={onLogout}
              variant="destructive"
              className="bg-red-600 hover:bg-red-700"
            >
              Logout from Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}