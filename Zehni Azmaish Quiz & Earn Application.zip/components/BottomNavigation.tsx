import React from 'react'
import { Button } from './ui/button'
import { Home, Trophy, Wallet, User, Shield } from 'lucide-react'

interface BottomNavigationProps {
  currentScreen: string
  onNavigate: (screen: any) => void
  isAdmin: boolean
}

export function BottomNavigation({ currentScreen, onNavigate, isAdmin }: BottomNavigationProps) {
  const navItems = [
    { id: 'dashboard', label: 'Home', icon: Home },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'wallet', label: 'Wallet', icon: Wallet },
    { id: 'profile', label: 'Profile', icon: User }
  ]

  if (isAdmin) {
    navItems.push({ id: 'admin', label: 'Admin', icon: Shield })
  }

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/10 backdrop-blur-md border-t border-white/20 p-4">
      <div className="flex justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon
          const isActive = currentScreen === item.id
          
          return (
            <Button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              variant="ghost"
              className={`flex flex-col items-center space-y-1 p-2 h-auto ${
                isActive ? 'text-purple-300' : 'text-white/70 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </Button>
          )
        })}
      </div>
    </div>
  )
}