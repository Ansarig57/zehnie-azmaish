import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { projectId } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';
import { 
  Wallet as WalletIcon, 
  CreditCard, 
  Smartphone, 
  Building2, 
  History,
  TrendingUp,
  DollarSign,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface WalletProps {
  user: any;
}

export function Wallet({ user }: WalletProps) {
  const [withdrawalHistory, setWithdrawalHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showWithdrawDialog, setShowWithdrawDialog] = useState(false);
  const [withdrawForm, setWithdrawForm] = useState({
    amount: '',
    method: '',
    accountDetails: ''
  });

  const points = user?.user_metadata?.points || 0;
  const earnings = user?.user_metadata?.earnings || 0;

  useEffect(() => {
    loadWithdrawalHistory();
  }, [user]);

  const loadWithdrawalHistory = async () => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/withdrawal-history/${user.id}`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      
      if (response.ok) {
        setWithdrawalHistory(data.withdrawals || []);
      }
    } catch (error) {
      console.error('Failed to load withdrawal history:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleWithdraw = async () => {
    if (!withdrawForm.amount || !withdrawForm.method || !withdrawForm.accountDetails) {
      toast.error('Please fill all fields');
      return;
    }

    const amount = parseFloat(withdrawForm.amount);
    if (amount < 200) {
      toast.error('Minimum withdrawal amount is 200 PKR');
      return;
    }

    if (amount > earnings) {
      toast.error('Insufficient balance');
      return;
    }

    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/withdraw`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            amount: amount,
            method: withdrawForm.method,
            accountDetails: withdrawForm.accountDetails
          })
        }
      );

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error);
      }

      toast.success('Withdrawal request submitted successfully!');
      setShowWithdrawDialog(false);
      setWithdrawForm({ amount: '', method: '', accountDetails: '' });
      loadWithdrawalHistory();
      
      // Refresh page to update user balance
      window.location.reload();
    } catch (error) {
      console.error('Withdrawal failed:', error);
      toast.error(error.message || 'Withdrawal failed');
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return <Clock className="w-5 h-5 text-yellow-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500';
      case 'rejected':
        return 'bg-red-500';
      default:
        return 'bg-yellow-500';
    }
  };

  const withdrawalMethods = [
    { value: 'jazzcash', label: 'JazzCash', icon: Smartphone },
    { value: 'easypaisa', label: 'EasyPaisa', icon: Smartphone },
    { value: 'bank', label: 'Bank Transfer', icon: Building2 }
  ];

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">💰 Your Wallet</h1>
        <p className="text-white/70">Manage your earnings and withdraw funds</p>
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 rounded-lg bg-yellow-400/10">
                <TrendingUp className="w-8 h-8 text-yellow-400" />
              </div>
              <div>
                <p className="text-sm text-white/70">Total Points</p>
                <p className="text-3xl font-bold">{points.toLocaleString()}</p>
                <p className="text-xs text-white/50">100 points = 1 PKR</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-3 rounded-lg bg-green-400/10">
                <DollarSign className="w-8 h-8 text-green-400" />
              </div>
              <div>
                <p className="text-sm text-white/70">Available Earnings</p>
                <p className="text-3xl font-bold">{earnings} PKR</p>
                <p className="text-xs text-white/50">Ready for withdrawal</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Withdrawal Section */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <WalletIcon className="w-5 h-5" />
            <span>Withdraw Funds</span>
          </CardTitle>
          <CardDescription className="text-white/70">
            Minimum withdrawal amount is 200 PKR
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 space-y-2">
              <p className="text-white/80">Available for withdrawal: <span className="font-bold text-green-400">{earnings} PKR</span></p>
              <p className="text-sm text-white/60">Processing time: 1-3 business days</p>
            </div>
            <Dialog open={showWithdrawDialog} onOpenChange={setShowWithdrawDialog}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  disabled={earnings < 200}
                >
                  <WalletIcon className="w-5 h-5 mr-2" />
                  Withdraw Funds
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-700 text-white">
                <DialogHeader>
                  <DialogTitle>Withdraw Funds</DialogTitle>
                  <DialogDescription className="text-gray-300">
                    Fill in the details to request a withdrawal
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (PKR)</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="Enter amount (min 200)"
                      value={withdrawForm.amount}
                      onChange={(e) => setWithdrawForm({ ...withdrawForm, amount: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                      min="200"
                      max={earnings}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="method">Withdrawal Method</Label>
                    <Select 
                      value={withdrawForm.method} 
                      onValueChange={(value) => setWithdrawForm({ ...withdrawForm, method: value })}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue placeholder="Select withdrawal method" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-600">
                        {withdrawalMethods.map((method) => {
                          const Icon = method.icon;
                          return (
                            <SelectItem key={method.value} value={method.value} className="text-white">
                              <div className="flex items-center space-x-2">
                                <Icon className="w-4 h-4" />
                                <span>{method.label}</span>
                              </div>
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="account">Account Details</Label>
                    <Input
                      id="account"
                      placeholder={
                        withdrawForm.method === 'bank' 
                          ? 'Account Number & Bank Name' 
                          : 'Mobile Number'
                      }
                      value={withdrawForm.accountDetails}
                      onChange={(e) => setWithdrawForm({ ...withdrawForm, accountDetails: e.target.value })}
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    onClick={handleWithdraw}
                    disabled={loading}
                    className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                  >
                    {loading ? 'Processing...' : 'Submit Request'}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </CardContent>
      </Card>

      {/* Withdrawal History */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <History className="w-5 h-5" />
            <span>Withdrawal History</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="text-white/70">Loading history...</div>
            </div>
          ) : withdrawalHistory.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-white/70">No withdrawal history yet</div>
              <p className="text-sm text-white/50 mt-2">Your withdrawal requests will appear here</p>
            </div>
          ) : (
            <div className="space-y-4">
              {withdrawalHistory.map((withdrawal, index) => (
                <div
                  key={index}
                  className="p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(withdrawal.status)}
                      <div>
                        <div className="font-medium">{withdrawal.amount} PKR</div>
                        <div className="text-sm text-white/70">
                          {withdrawal.method === 'jazzcash' && 'JazzCash'}
                          {withdrawal.method === 'easypaisa' && 'EasyPaisa'}
                          {withdrawal.method === 'bank' && 'Bank Transfer'}
                          {' '} • {withdrawal.accountDetails}
                        </div>
                        <div className="text-xs text-white/50">
                          Requested: {new Date(withdrawal.requestDate).toLocaleDateString()}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className={getStatusColor(withdrawal.status)}>
                        {withdrawal.status.toUpperCase()}
                      </Badge>
                      {withdrawal.status === 'rejected' && withdrawal.rejectionReason && (
                        <div className="text-xs text-red-400 mt-1">
                          {withdrawal.rejectionReason}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}