import React, { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from './ui/card'
import { Button } from './ui/button'
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar'
import { Badge } from './ui/badge'
import { ArrowLeft, Trophy, Crown, Medal, Star } from 'lucide-react'
import { useAuth } from './AuthContext'
import { projectId, publicAnonKey } from '../utils/supabase/info'

interface LeaderboardEntry {
  name: string
  points: number
  avatar: string
  rank?: number
}

interface LeaderboardScreenProps {
  onBack: () => void
}

export function LeaderboardScreen({ onBack }: LeaderboardScreenProps) {
  const { user } = useAuth()
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPeriod, setSelectedPeriod] = useState<'daily' | 'weekly' | 'monthly' | 'all'>('all')

  useEffect(() => {
    fetchLeaderboard()
  }, [selectedPeriod])

  const fetchLeaderboard = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/leaderboard`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      })
      
      if (response.ok) {
        const data = await response.json()
        const rankedLeaderboard = data.leaderboard.map((entry: LeaderboardEntry, index: number) => ({
          ...entry,
          rank: index + 1
        }))
        setLeaderboard(rankedLeaderboard)
      }
    } catch (error) {
      console.error('Error fetching leaderboard:', error)
    } finally {
      setLoading(false)
    }
  }

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-400" />
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />
      case 3:
        return <Medal className="w-6 h-6 text-amber-600" />
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-white text-sm">#{rank}</span>
    }
  }

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-500 to-amber-500'
      case 2:
        return 'bg-gradient-to-r from-gray-400 to-slate-500'
      case 3:
        return 'bg-gradient-to-r from-amber-600 to-orange-600'
      default:
        return 'bg-white/10'
    }
  }

  const getAvatarUrl = (avatar: string) => {
    // Return placeholder avatars based on avatar name
    const avatars = {
      'default': '/placeholder.svg?height=40&width=40',
      'admin': '/placeholder.svg?height=40&width=40',
      'user1': '/placeholder.svg?height=40&width=40',
      'user2': '/placeholder.svg?height=40&width=40',
      'user3': '/placeholder.svg?height=40&width=40'
    }
    return avatars[avatar as keyof typeof avatars] || '/placeholder.svg?height=40&width=40'
  }

  const currentUserRank = leaderboard.findIndex(entry => entry.name === user?.name) + 1

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl text-white">Leaderboard</h1>
        </div>
        <Trophy className="w-8 h-8 text-yellow-400" />
      </div>

      {/* Period Selection */}
      <div className="flex space-x-2 mb-6 overflow-x-auto">
        {[
          { key: 'daily', label: 'Daily' },
          { key: 'weekly', label: 'Weekly' },
          { key: 'monthly', label: 'Monthly' },
          { key: 'all', label: 'All Time' }
        ].map((period) => (
          <Button
            key={period.key}
            onClick={() => setSelectedPeriod(period.key as any)}
            variant={selectedPeriod === period.key ? 'default' : 'outline'}
            size="sm"
            className={`whitespace-nowrap ${
              selectedPeriod === period.key
                ? 'bg-purple-600 text-white'
                : 'border-white/20 text-white hover:bg-white/10'
            }`}
          >
            {period.label}
          </Button>
        ))}
      </div>

      {/* Current User Rank */}
      {user && currentUserRank > 0 && currentUserRank > 3 && (
        <Card className="bg-purple-600/20 border-purple-400 mb-4">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-8 h-8 bg-purple-500 rounded-full">
                  <span className="text-white text-sm">#{currentUserRank}</span>
                </div>
                <div>
                  <p className="text-white">Your Rank</p>
                  <p className="text-purple-200 text-sm">{user.points.toLocaleString()} points</p>
                </div>
              </div>
              <Star className="w-6 h-6 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Top 3 Podium */}
      {leaderboard.length >= 3 && (
        <div className="flex items-end justify-center space-x-4 mb-6">
          {/* 2nd Place */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-gray-400 to-slate-500 p-4 rounded-lg mb-2">
              <Avatar className="w-16 h-16 mx-auto mb-2">
                <AvatarImage src={getAvatarUrl(leaderboard[1].avatar)} />
                <AvatarFallback>{leaderboard[1].name[0]}</AvatarFallback>
              </Avatar>
              <Medal className="w-6 h-6 text-gray-300 mx-auto" />
            </div>
            <p className="text-white text-sm truncate max-w-20">{leaderboard[1].name}</p>
            <p className="text-gray-300 text-xs">{leaderboard[1].points.toLocaleString()}</p>
          </div>

          {/* 1st Place */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-yellow-500 to-amber-500 p-4 rounded-lg mb-2 transform scale-110">
              <Avatar className="w-20 h-20 mx-auto mb-2">
                <AvatarImage src={getAvatarUrl(leaderboard[0].avatar)} />
                <AvatarFallback>{leaderboard[0].name[0]}</AvatarFallback>
              </Avatar>
              <Crown className="w-8 h-8 text-yellow-200 mx-auto" />
            </div>
            <p className="text-white truncate max-w-24">{leaderboard[0].name}</p>
            <p className="text-yellow-300 text-sm">{leaderboard[0].points.toLocaleString()}</p>
          </div>

          {/* 3rd Place */}
          <div className="text-center">
            <div className="bg-gradient-to-r from-amber-600 to-orange-600 p-4 rounded-lg mb-2">
              <Avatar className="w-16 h-16 mx-auto mb-2">
                <AvatarImage src={getAvatarUrl(leaderboard[2].avatar)} />
                <AvatarFallback>{leaderboard[2].name[0]}</AvatarFallback>
              </Avatar>
              <Medal className="w-6 h-6 text-amber-300 mx-auto" />
            </div>
            <p className="text-white text-sm truncate max-w-20">{leaderboard[2].name}</p>
            <p className="text-amber-300 text-xs">{leaderboard[2].points.toLocaleString()}</p>
          </div>
        </div>
      )}

      {/* Full Leaderboard */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white">Rankings</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto"></div>
              <p className="text-purple-200 mt-2">Loading rankings...</p>
            </div>
          ) : leaderboard.length === 0 ? (
            <p className="text-purple-200 text-center py-8">No rankings available</p>
          ) : (
            <div className="space-y-2">
              {leaderboard.map((entry, index) => {
                const isCurrentUser = entry.name === user?.name
                
                return (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      isCurrentUser ? 'bg-purple-500/30 border border-purple-400' : getRankBg(entry.rank || index + 1)
                    } ${entry.rank && entry.rank <= 3 ? 'border border-yellow-400/30' : ''}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center justify-center w-8 h-8">
                        {getRankIcon(entry.rank || index + 1)}
                      </div>
                      
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={getAvatarUrl(entry.avatar)} />
                        <AvatarFallback>{entry.name[0]}</AvatarFallback>
                      </Avatar>
                      
                      <div>
                        <p className={`text-white ${isCurrentUser ? 'font-bold' : ''}`}>
                          {entry.name} {isCurrentUser && '(You)'}
                        </p>
                        <p className="text-purple-200 text-sm">
                          {entry.points.toLocaleString()} points
                        </p>
                      </div>
                    </div>

                    {entry.rank && entry.rank <= 10 && (
                      <Badge variant="secondary" className="bg-yellow-500/20 text-yellow-400">
                        Top {entry.rank <= 3 ? '3' : '10'}
                      </Badge>
                    )}
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Achievement Info */}
      <Card className="bg-white/5 border-white/10 mt-4">
        <CardContent className="p-4">
          <div className="flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <p className="text-purple-200 text-sm">
              Keep playing to climb the leaderboard and unlock exclusive achievements!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}