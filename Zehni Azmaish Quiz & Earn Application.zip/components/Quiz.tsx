import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { projectId } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';
import { 
  Brain, 
  Clock, 
  CheckCircle, 
  XCircle, 
  ArrowLeft, 
  RotateCcw,
  Zap,
  Target,
  Lightbulb
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface QuizProps {
  user: any;
  onNavigate: (page: string) => void;
}

export function Quiz({ user, onNavigate }: QuizProps) {
  const [currentScreen, setCurrentScreen] = useState('categories'); // categories, difficulty, quiz, results
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('');
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(-1);
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(10);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [lifeline5050Used, setLifeline5050Used] = useState(false);
  const [hiddenOptions, setHiddenOptions] = useState([]);

  const categories = [
    { name: 'General Knowledge', icon: Brain, color: 'bg-purple-500' },
    { name: 'Islamic', icon: Target, color: 'bg-green-500' },
    { name: 'Current Affairs', icon: Zap, color: 'bg-blue-500' },
    { name: 'Sports', icon: Target, color: 'bg-orange-500' },
    { name: 'Science', icon: Brain, color: 'bg-indigo-500' },
    { name: 'History', icon: Target, color: 'bg-amber-500' },
    { name: 'Math', icon: Brain, color: 'bg-red-500' },
    { name: 'English', icon: Target, color: 'bg-pink-500' },
    { name: 'Urdu', icon: Brain, color: 'bg-teal-500' }
  ];

  const difficulties = ['Beginner', 'Pro', 'Expert', 'Legend'];

  useEffect(() => {
    let timer;
    if (currentScreen === 'quiz' && timeLeft > 0) {
      timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    } else if (currentScreen === 'quiz' && timeLeft === 0) {
      handleAnswer(-1); // Auto-skip on timeout
    }
    return () => clearTimeout(timer);
  }, [timeLeft, currentScreen]);

  const loadQuestions = async (category, difficulty) => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/questions/${category}/${difficulty}`,
        {
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error);
      }

      if (data.questions.length === 0) {
        toast.error('No questions available for this category and difficulty');
        setCurrentScreen('categories');
        return;
      }

      setQuestions(data.questions);
      setCurrentScreen('quiz');
      setCurrentQuestion(0);
      setAnswers(new Array(data.questions.length).fill(-1));
      setTimeLeft(10);
      setLifeline5050Used(false);
      setHiddenOptions([]);
    } catch (error) {
      console.error('Failed to load questions:', error);
      toast.error('Failed to load questions');
      setCurrentScreen('categories');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (answerIndex) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = answerIndex;
    setAnswers(newAnswers);

    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(-1);
      setTimeLeft(10);
      setHiddenOptions([]);
    } else {
      submitQuiz(newAnswers);
    }
  };

  const submitQuiz = async (finalAnswers) => {
    setLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/submit-quiz`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            answers: finalAnswers,
            questions: questions
          })
        }
      );

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error);
      }

      setResults(data);
      setCurrentScreen('results');
    } catch (error) {
      console.error('Failed to submit quiz:', error);
      toast.error('Failed to submit quiz');
    } finally {
      setLoading(false);
    }
  };

  const use5050Lifeline = () => {
    if (lifeline5050Used || currentScreen !== 'quiz') return;

    const currentQ = questions[currentQuestion];
    const correctAnswer = currentQ.correctAnswer;
    const wrongOptions = [0, 1, 2, 3].filter(i => i !== correctAnswer);
    
    // Randomly select 2 wrong options to hide
    const optionsToHide = wrongOptions.sort(() => Math.random() - 0.5).slice(0, 2);
    
    setHiddenOptions(optionsToHide);
    setLifeline5050Used(true);
    toast.success('50:50 lifeline used! Two incorrect options removed.');
  };

  const resetQuiz = () => {
    setCurrentScreen('categories');
    setSelectedCategory('');
    setSelectedDifficulty('');
    setQuestions([]);
    setCurrentQuestion(0);
    setSelectedAnswer(-1);
    setAnswers([]);
    setTimeLeft(10);
    setResults(null);
    setLifeline5050Used(false);
    setHiddenOptions([]);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  // Category Selection Screen
  if (currentScreen === 'categories') {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => onNavigate('dashboard')}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Choose Quiz Category</CardTitle>
            <CardDescription className="text-white/70">
              Select a category to test your knowledge
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((category, index) => {
                const Icon = category.icon;
                return (
                  <Button
                    key={index}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2 bg-white/5 border-white/20 text-white hover:bg-white/10"
                    onClick={() => {
                      setSelectedCategory(category.name);
                      setCurrentScreen('difficulty');
                    }}
                  >
                    <div className={`p-2 rounded-lg ${category.color}`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <span className="text-sm font-medium">{category.name}</span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Quiz Rules</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <p className="text-white/80">• Each question has 10 seconds time limit</p>
            <p className="text-white/80">• Correct answer: +10 points</p>
            <p className="text-white/80">• Wrong answer: -5 points</p>
            <p className="text-white/80">• 100 points = 1 PKR</p>
            <p className="text-white/80">• Use 50:50 lifeline to eliminate 2 wrong options</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Difficulty Selection Screen
  if (currentScreen === 'difficulty') {
    return (
      <div className="space-y-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => setCurrentScreen('categories')}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Back to Categories
          </Button>
          <h2 className="text-xl font-bold text-white">{selectedCategory}</h2>
        </div>

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle>Choose Difficulty Level</CardTitle>
            <CardDescription className="text-white/70">
              Start with Beginner and progress to unlock higher levels
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {difficulties.map((difficulty, index) => {
                const colors = ['bg-green-500', 'bg-yellow-500', 'bg-orange-500', 'bg-red-500'];
                return (
                  <Button
                    key={index}
                    variant="outline"
                    className="h-20 flex flex-col items-center justify-center space-y-2 bg-white/5 border-white/20 text-white hover:bg-white/10"
                    onClick={() => {
                      setSelectedDifficulty(difficulty);
                      loadQuestions(selectedCategory, difficulty);
                    }}
                  >
                    <div className={`p-3 rounded-lg ${colors[index]}`}>
                      <Target className="w-6 h-6 text-white" />
                    </div>
                    <span className="font-medium">{difficulty}</span>
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Quiz Screen
  if (currentScreen === 'quiz' && questions.length > 0) {
    const currentQ = questions[currentQuestion];
    const progress = ((currentQuestion + 1) / questions.length) * 100;

    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={resetQuiz}
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Exit Quiz
          </Button>
          
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-white/20 text-white">
              {currentQuestion + 1} of {questions.length}
            </Badge>
            <div className="flex items-center space-x-2 text-white">
              <Clock className="w-5 h-5" />
              <span className={`font-bold ${timeLeft <= 3 ? 'text-red-400' : ''}`}>
                {timeLeft}s
              </span>
            </div>
          </div>
        </div>

        <Progress value={progress} className="h-2" />

        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle className="text-xl">{currentQ.question}</CardTitle>
            <div className="flex items-center justify-between">
              <Badge className="bg-blue-500">
                {selectedCategory} - {selectedDifficulty}
              </Badge>
              {!lifeline5050Used && (
                <Button
                  size="sm"
                  onClick={use5050Lifeline}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <Lightbulb className="w-4 h-4 mr-2" />
                  50:50
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentQ.options.map((option, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className={`
                    p-4 h-auto text-left justify-start bg-white/5 border-white/20 text-white hover:bg-white/10
                    ${selectedAnswer === index ? 'bg-blue-500/20 border-blue-500' : ''}
                    ${hiddenOptions.includes(index) ? 'opacity-30 pointer-events-none' : ''}
                  `}
                  onClick={() => {
                    setSelectedAnswer(index);
                    setTimeout(() => handleAnswer(index), 500);
                  }}
                  disabled={hiddenOptions.includes(index)}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center font-bold">
                      {String.fromCharCode(65 + index)}
                    </div>
                    <span>{option}</span>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Results Screen
  if (currentScreen === 'results' && results) {
    return (
      <div className="space-y-6">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl">Quiz Complete!</CardTitle>
            <CardDescription className="text-white/70 text-lg">
              Here are your results
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-white/5 rounded-lg">
                <div className="text-3xl font-bold text-green-400">{results.score}</div>
                <div className="text-white/70">Points Scored</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-lg">
                <div className="text-3xl font-bold text-blue-400">{results.accuracy}%</div>
                <div className="text-white/70">Accuracy</div>
              </div>
              <div className="text-center p-4 bg-white/5 rounded-lg">
                <div className="text-3xl font-bold text-purple-400">
                  {results.correctAnswers}/{results.totalQuestions}
                </div>
                <div className="text-white/70">Correct Answers</div>
              </div>
            </div>

            <div className="text-center space-y-2">
              <p className="text-white/80">
                New Total Points: <span className="font-bold text-yellow-400">{results.newPoints}</span>
              </p>
              <p className="text-white/80">
                New Earnings: <span className="font-bold text-green-400">{results.newEarnings} PKR</span>
              </p>
            </div>

            <div className="flex flex-col md:flex-row gap-4">
              <Button
                onClick={resetQuiz}
                className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Play Again
              </Button>
              <Button
                onClick={() => onNavigate('dashboard')}
                variant="outline"
                className="flex-1 bg-white/5 border-white/20 text-white hover:bg-white/10"
              >
                <ArrowLeft className="w-5 h-5 mr-2" />
                Back to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}