import React, { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from './ui/card'
import { Button } from './ui/button'
import { Input } from './ui/input'
import { Label } from './ui/label'
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar'
import { Badge } from './ui/badge'
import { ArrowLeft, User, Mail, Phone, Trophy, Star, Calendar, Wallet, Brain, Target } from 'lucide-react'
import { useAuth } from './AuthContext'
import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from '../utils/supabase/info'

interface ProfileScreenProps {
  onBack: () => void
}

export function ProfileScreen({ onBack }: ProfileScreenProps) {
  const { user, signOut, refreshUser } = useAuth()
  const [editMode, setEditMode] = useState(false)
  const [loading, setLoading] = useState(false)
  const [selectedAvatar, setSelectedAvatar] = useState(user?.avatar || 'default')
  const [name, setName] = useState(user?.name || '')

  const supabase = createClient(
    `https://${projectId}.supabase.co`,
    publicAnonKey
  )

  const avatarOptions = [
    { id: 'default', name: 'Default', emoji: '👤' },
    { id: 'cool', name: 'Cool', emoji: '😎' },
    { id: 'happy', name: 'Happy', emoji: '😊' },
    { id: 'smart', name: 'Smart', emoji: '🤓' },
    { id: 'star', name: 'Star', emoji: '⭐' },
    { id: 'brain', name: 'Brain', emoji: '🧠' },
    { id: 'trophy', name: 'Trophy', emoji: '🏆' },
    { id: 'fire', name: 'Fire', emoji: '🔥' }
  ]

  const handleSaveProfile = async () => {
    setLoading(true)
    try {
      const { data: { session } } = await supabase.auth.getSession()
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/update-profile`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${session?.access_token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name,
          avatar: selectedAvatar
        })
      })
      
      if (response.ok) {
        setEditMode(false)
        await refreshUser()
      }
    } catch (error) {
      console.error('Error updating profile:', error)
    } finally {
      setLoading(false)
    }
  }

  const getAvatarDisplay = (avatarId: string) => {
    const avatar = avatarOptions.find(a => a.id === avatarId)
    return avatar ? avatar.emoji : '👤'
  }

  const achievements = [
    {
      id: 'first_quiz',
      name: 'First Steps',
      description: 'Complete your first quiz',
      icon: <Brain className="w-6 h-6 text-blue-400" />,
      unlocked: user && user.points > 0
    },
    {
      id: 'hundred_points',
      name: 'Century',
      description: 'Earn 100 points',
      icon: <Target className="w-6 h-6 text-green-400" />,
      unlocked: user && user.points >= 100
    },
    {
      id: 'first_earning',
      name: 'Money Maker',
      description: 'Earn your first PKR',
      icon: <Wallet className="w-6 h-6 text-yellow-400" />,
      unlocked: user && user.totalEarnings > 0
    },
    {
      id: 'week_streak',
      name: 'Dedicated',
      description: 'Login for 7 consecutive days',
      icon: <Calendar className="w-6 h-6 text-purple-400" />,
      unlocked: user && user.dailyLoginStreak >= 7
    },
    {
      id: 'quiz_master',
      name: 'Quiz Master',
      description: 'Earn 1000 points',
      icon: <Star className="w-6 h-6 text-orange-400" />,
      unlocked: user && user.points >= 1000
    },
    {
      id: 'champion',
      name: 'Champion',
      description: 'Earn 5000 points',
      icon: <Trophy className="w-6 h-6 text-red-400" />,
      unlocked: user && user.points >= 5000
    }
  ]

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-2xl text-white">Profile</h1>
        </div>
        <User className="w-8 h-8 text-purple-400" />
      </div>

      {/* Profile Card */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 mb-6">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-purple-500 flex items-center justify-center text-3xl">
                {getAvatarDisplay(selectedAvatar)}
              </div>
              {editMode && (
                <Button
                  onClick={() => setEditMode(true)}
                  size="sm"
                  className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0 bg-purple-600 hover:bg-purple-700"
                >
                  ✏️
                </Button>
              )}
            </div>
            <div className="flex-1">
              {editMode ? (
                <div className="space-y-2">
                  <Input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="bg-white/10 border-white/20 text-white"
                    placeholder="Your name"
                  />
                </div>
              ) : (
                <>
                  <h2 className="text-xl text-white">{user.name}</h2>
                  <p className="text-purple-200">
                    {user.role === 'admin' ? 'Administrator' : 'Quiz Player'}
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Avatar Selection */}
          {editMode && (
            <div className="mb-6">
              <Label className="text-white mb-3 block">Choose Avatar</Label>
              <div className="grid grid-cols-4 gap-3">
                {avatarOptions.map((avatar) => (
                  <Button
                    key={avatar.id}
                    onClick={() => setSelectedAvatar(avatar.id)}
                    variant="outline"
                    className={`h-16 border-2 ${
                      selectedAvatar === avatar.id
                        ? 'border-purple-400 bg-purple-500/30'
                        : 'border-white/20 hover:border-white/40'
                    }`}
                  >
                    <div className="text-center">
                      <div className="text-2xl mb-1">{avatar.emoji}</div>
                      <div className="text-xs text-white">{avatar.name}</div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          )}

          {/* Contact Info */}
          <div className="space-y-3">
            <div className="flex items-center space-x-3">
              <Mail className="w-5 h-5 text-purple-400" />
              <span className="text-white">{user.email}</span>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="w-5 h-5 text-purple-400" />
              <span className="text-white">{user.phone}</span>
            </div>
          </div>

          {/* Edit/Save Buttons */}
          <div className="mt-6 flex space-x-3">
            {editMode ? (
              <>
                <Button
                  onClick={handleSaveProfile}
                  disabled={loading}
                  className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                >
                  {loading ? 'Saving...' : 'Save Changes'}
                </Button>
                <Button
                  onClick={() => {
                    setEditMode(false)
                    setName(user.name)
                    setSelectedAvatar(user.avatar)
                  }}
                  variant="outline"
                  className="flex-1 border-white/20 text-white hover:bg-white/10"
                >
                  Cancel
                </Button>
              </>
            ) : (
              <Button
                onClick={() => setEditMode(true)}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                Edit Profile
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-4 text-center">
            <Brain className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <p className="text-white text-xl">{user.points.toLocaleString()}</p>
            <p className="text-purple-200 text-sm">Total Points</p>
          </CardContent>
        </Card>

        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardContent className="p-4 text-center">
            <Calendar className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <p className="text-white text-xl">{user.dailyLoginStreak}</p>
            <p className="text-purple-200 text-sm">Day Streak</p>
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 mb-6">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Trophy className="w-5 h-5 text-yellow-400" />
            <span>Achievements</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`flex items-center space-x-3 p-3 rounded-lg ${
                  achievement.unlocked
                    ? 'bg-green-500/20 border border-green-400/30'
                    : 'bg-white/5 border border-white/10'
                }`}
              >
                <div className={achievement.unlocked ? '' : 'opacity-50'}>
                  {achievement.icon}
                </div>
                <div className="flex-1">
                  <p className={`${achievement.unlocked ? 'text-white' : 'text-gray-400'}`}>
                    {achievement.name}
                  </p>
                  <p className={`text-sm ${achievement.unlocked ? 'text-purple-200' : 'text-gray-500'}`}>
                    {achievement.description}
                  </p>
                </div>
                {achievement.unlocked && (
                  <Badge className="bg-green-500 text-white">Unlocked</Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Sign Out */}
      <Button
        onClick={signOut}
        variant="outline"
        className="w-full border-red-400 text-red-400 hover:bg-red-500/20"
      >
        Sign Out
      </Button>
    </div>
  )
}