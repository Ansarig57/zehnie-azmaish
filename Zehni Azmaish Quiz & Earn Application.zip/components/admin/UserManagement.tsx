import React, { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Users } from 'lucide-react'
import { adminApi } from '../../utils/api'

interface User {
  id: string
  name: string
  email: string
  points: number
  totalEarnings: number
  role: string
}

export function UserManagement() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchUsers()
  }, [])

  const fetchUsers = async () => {
    try {
      const data = await adminApi.getUsers()
      setUsers(data.users)
    } catch (error) {
      console.error('Error fetching users:', error)
    }
  }

  const updateUserPoints = async (userId: string, newPoints: number) => {
    try {
      setLoading(true)
      await adminApi.updateUserPoints(userId, newPoints)
      await fetchUsers()
    } catch (error) {
      console.error('Error updating user points:', error)
      alert('Error updating user points')
    } finally {
      setLoading(false)
    }
  }

  const handlePointsUpdate = (userId: string, input: HTMLInputElement) => {
    const points = parseInt(input.value)
    if (!isNaN(points)) {
      updateUserPoints(userId, points)
      input.value = ''
    }
  }

  return (
    <Card className="bg-white/10 backdrop-blur-md border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Users className="w-5 h-5" />
          <span>User Management</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {users.map((userData) => (
            <div key={userData.id} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
              <div className="flex-1">
                <p className="text-white">{userData.name}</p>
                <p className="text-purple-200 text-sm">{userData.email}</p>
                <p className="text-purple-200 text-sm">
                  Points: {userData.points.toLocaleString()} | Earnings: ₨{userData.totalEarnings}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Input
                  type="number"
                  placeholder="New points"
                  className="w-32 bg-white/10 border-white/20 text-white"
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      handlePointsUpdate(userData.id, e.target as HTMLInputElement)
                    }
                  }}
                />
                <Button
                  size="sm"
                  disabled={loading}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                  onClick={(e) => {
                    const input = (e.target as HTMLElement).parentElement?.querySelector('input') as HTMLInputElement
                    if (input?.value) {
                      handlePointsUpdate(userData.id, input)
                    }
                  }}
                >
                  Update
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}