import React, { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { Label } from '../ui/label'
import { Textarea } from '../ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select'
import { Plus, Brain } from 'lucide-react'
import { adminApi } from '../../utils/api'
import { QUIZ_CATEGORIES, DIFFICULTY_LEVELS } from '../constants'

export function QuestionManagement() {
  const [loading, setLoading] = useState(false)
  
  const [questionForm, setQuestionForm] = useState({
    question: '',
    option1: '',
    option2: '',
    option3: '',
    option4: '',
    correctAnswer: 0,
    category: '',
    difficulty: '',
    explanation: ''
  })

  const [aiForm, setAiForm] = useState({
    category: '',
    topic: '',
    quantity: 5
  })

  const addQuestion = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      await adminApi.addQuestion({
        question: questionForm.question,
        options: [questionForm.option1, questionForm.option2, questionForm.option3, questionForm.option4],
        correctAnswer: questionForm.correctAnswer,
        category: questionForm.category,
        difficulty: questionForm.difficulty,
        explanation: questionForm.explanation
      })
      
      setQuestionForm({
        question: '',
        option1: '',
        option2: '',
        option3: '',
        option4: '',
        correctAnswer: 0,
        category: '',
        difficulty: '',
        explanation: ''
      })
      alert('Question added successfully!')
    } catch (error) {
      console.error('Error adding question:', error)
      alert('Error adding question')
    } finally {
      setLoading(false)
    }
  }

  const generateAIQuestions = async () => {
    setLoading(true)
    try {
      // Mock AI generation for demo
      const mockQuestions = []
      for (let i = 0; i < aiForm.quantity; i++) {
        mockQuestions.push({
          question: `AI Generated Question ${i + 1} about ${aiForm.topic || aiForm.category}`,
          options: ['Option A', 'Option B', 'Option C', 'Option D'],
          correctAnswer: Math.floor(Math.random() * 4),
          category: aiForm.category,
          difficulty: DIFFICULTY_LEVELS[Math.floor(Math.random() * DIFFICULTY_LEVELS.length)],
          explanation: `This is an AI-generated explanation for question ${i + 1}.`
        })
      }
      
      for (const question of mockQuestions) {
        await adminApi.addQuestion(question)
      }
      
      alert(`Successfully generated ${aiForm.quantity} questions!`)
      setAiForm({ category: '', topic: '', quantity: 5 })
    } catch (error) {
      console.error('Error generating AI questions:', error)
      alert('Error generating questions')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Manual Question Add */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add Question Manually</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={addQuestion} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white">Category</Label>
                <Select value={questionForm.category} onValueChange={(value) => setQuestionForm(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {QUIZ_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white">Difficulty</Label>
                <Select value={questionForm.difficulty} onValueChange={(value) => setQuestionForm(prev => ({ ...prev, difficulty: value }))}>
                  <SelectTrigger className="bg-white/10 border-white/20 text-white">
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    {DIFFICULTY_LEVELS.map(diff => (
                      <SelectItem key={diff} value={diff}>{diff}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-white">Question</Label>
              <Textarea
                value={questionForm.question}
                onChange={(e) => setQuestionForm(prev => ({ ...prev, question: e.target.value }))}
                className="bg-white/10 border-white/20 text-white"
                placeholder="Enter your question"
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              {['option1', 'option2', 'option3', 'option4'].map((option, index) => (
                <div key={option}>
                  <Label className="text-white">Option {String.fromCharCode(65 + index)}</Label>
                  <Input
                    value={questionForm[option as keyof typeof questionForm] as string}
                    onChange={(e) => setQuestionForm(prev => ({ ...prev, [option]: e.target.value }))}
                    className="bg-white/10 border-white/20 text-white"
                    required
                  />
                </div>
              ))}
            </div>

            <div>
              <Label className="text-white">Correct Answer</Label>
              <Select value={questionForm.correctAnswer.toString()} onValueChange={(value) => setQuestionForm(prev => ({ ...prev, correctAnswer: parseInt(value) }))}>
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select correct answer" />
                </SelectTrigger>
                <SelectContent>
                  {['A', 'B', 'C', 'D'].map((letter, index) => (
                    <SelectItem key={index} value={index.toString()}>Option {letter}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-white">Explanation</Label>
              <Textarea
                value={questionForm.explanation}
                onChange={(e) => setQuestionForm(prev => ({ ...prev, explanation: e.target.value }))}
                className="bg-white/10 border-white/20 text-white"
                placeholder="Explain the correct answer"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-green-600 hover:bg-green-700 text-white"
            >
              {loading ? 'Adding...' : 'Add Question'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* AI Question Generation */}
      <Card className="bg-gradient-to-r from-purple-600 to-pink-600 border-purple-400">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Brain className="w-5 h-5" />
            <span>AI Question Generator</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-white">Category</Label>
                <Select value={aiForm.category} onValueChange={(value) => setAiForm(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="bg-white/20 border-white/30 text-white">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {QUIZ_CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white">Quantity</Label>
                <Input
                  type="number"
                  min="1"
                  max="100"
                  value={aiForm.quantity}
                  onChange={(e) => setAiForm(prev => ({ ...prev, quantity: parseInt(e.target.value) }))}
                  className="bg-white/20 border-white/30 text-white"
                />
              </div>
            </div>

            <div>
              <Label className="text-white">Topic (Optional)</Label>
              <Input
                value={aiForm.topic}
                onChange={(e) => setAiForm(prev => ({ ...prev, topic: e.target.value }))}
                className="bg-white/20 border-white/30 text-white"
                placeholder="Specific topic for questions"
              />
            </div>

            <Button
              onClick={generateAIQuestions}
              disabled={loading || !aiForm.category}
              className="w-full bg-white/20 hover:bg-white/30 text-white"
            >
              {loading ? 'Generating...' : `Generate ${aiForm.quantity} Questions`}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}