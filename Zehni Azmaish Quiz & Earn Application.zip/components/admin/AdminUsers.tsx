import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Users, Edit, Shield, Calendar } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: string;
  points: number;
  earnings: number;
  loginStreak: number;
  lastLogin: string | null;
}

interface AdminUsersProps {
  users: User[];
  onUpdateUserPoints: (userId: string, points: number) => Promise<void>;
}

export function AdminUsers({ users, onUpdateUserPoints }: AdminUsersProps) {
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [newPoints, setNewPoints] = useState('');
  const [loading, setLoading] = useState(false);

  const handleUpdatePoints = async () => {
    if (!editingUser || !newPoints) return;

    const points = parseInt(newPoints);
    if (isNaN(points) || points < 0) {
      toast.error('Please enter a valid points value');
      return;
    }

    setLoading(true);
    try {
      await onUpdateUserPoints(editingUser.id, points);
      setEditingUser(null);
      setNewPoints('');
    } catch (error) {
      console.error('Failed to update points:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Users className="w-5 h-5" />
          <span>User Management</span>
        </CardTitle>
        <CardDescription className="text-white/70">
          View and manage all registered users
        </CardDescription>
      </CardHeader>
      <CardContent>
        {users.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-12 h-12 text-white/30 mx-auto mb-4" />
            <div className="text-white/70">No users found</div>
          </div>
        ) : (
          <div className="space-y-4">
            {users.map((user) => (
              <div
                key={user.id}
                className="p-4 bg-white/5 rounded-lg border border-white/10"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <div>
                        <div className="font-medium">{user.name}</div>
                        <div className="text-sm text-white/70">{user.email}</div>
                        {user.phone && (
                          <div className="text-xs text-white/50">{user.phone}</div>
                        )}
                      </div>
                      <Badge className={user.role === 'admin' ? 'bg-red-500' : 'bg-blue-500'}>
                        {user.role.toUpperCase()}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="text-white/50">Points</div>
                        <div className="font-medium">{user.points.toLocaleString()}</div>
                      </div>
                      <div>
                        <div className="text-white/50">Earnings</div>
                        <div className="font-medium">{user.earnings} PKR</div>
                      </div>
                      <div>
                        <div className="text-white/50">Login Streak</div>
                        <div className="font-medium">{user.loginStreak} days</div>
                      </div>
                      <div>
                        <div className="text-white/50">Last Login</div>
                        <div className="font-medium">
                          {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-white/10 border-white/20 text-white hover:bg-white/20"
                          onClick={() => {
                            setEditingUser(user);
                            setNewPoints(user.points.toString());
                          }}
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Points
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-gray-900 border-gray-700 text-white">
                        <DialogHeader>
                          <DialogTitle>Update User Points</DialogTitle>
                          <DialogDescription className="text-gray-300">
                            Modify points for {editingUser?.name}
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <label className="text-sm font-medium">Points</label>
                            <Input
                              type="number"
                              value={newPoints}
                              onChange={(e) => setNewPoints(e.target.value)}
                              className="bg-gray-800 border-gray-600 text-white"
                              placeholder="Enter new points value"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button
                            onClick={handleUpdatePoints}
                            disabled={loading}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            {loading ? 'Updating...' : 'Update Points'}
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}