import React, { useState, useEffect } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card'
import { Button } from '../ui/button'
import { Textarea } from '../ui/textarea'
import { Check, X, Wallet } from 'lucide-react'
import { adminApi } from '../../utils/api'

interface WithdrawalRequest {
  id: string
  userId: string
  userName: string
  amount: number
  method: string
  accountDetails: string
  status: string
  requestDate: string
}

export function WithdrawalManagement() {
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([])
  const [processing, setProcessing] = useState<string | null>(null)
  const [rejectReason, setRejectReason] = useState('')
  const [showRejectForm, setShowRejectForm] = useState<string | null>(null)

  useEffect(() => {
    fetchWithdrawals()
  }, [])

  const fetchWithdrawals = async () => {
    try {
      const data = await adminApi.getWithdrawals()
      setWithdrawals(data.withdrawals)
    } catch (error) {
      console.error('Error fetching withdrawals:', error)
    }
  }

  const processWithdrawal = async (withdrawalId: string, status: 'approved' | 'rejected', reason?: string) => {
    try {
      setProcessing(withdrawalId)
      await adminApi.processWithdrawal(withdrawalId, status, reason)
      await fetchWithdrawals()
      setShowRejectForm(null)
      setRejectReason('')
    } catch (error) {
      console.error('Error processing withdrawal:', error)
      alert('Error processing withdrawal')
    } finally {
      setProcessing(null)
    }
  }

  const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending')
  const processedWithdrawals = withdrawals.filter(w => w.status !== 'pending')

  return (
    <div className="space-y-6">
      {/* Pending Withdrawals */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Wallet className="w-5 h-5" />
            <span>Pending Withdrawals ({pendingWithdrawals.length})</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pendingWithdrawals.length === 0 ? (
            <p className="text-purple-200 text-center py-8">No pending withdrawal requests</p>
          ) : (
            <div className="space-y-4">
              {pendingWithdrawals.map((withdrawal) => (
                <div key={withdrawal.id} className="p-4 bg-yellow-500/20 border border-yellow-400 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="text-white">{withdrawal.userName}</p>
                      <p className="text-yellow-200 text-sm">{withdrawal.method.toUpperCase()}</p>
                      <p className="text-yellow-200 text-sm">Account: {withdrawal.accountDetails}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-white text-xl">₨{withdrawal.amount}</p>
                      <p className="text-yellow-200 text-sm">
                        {new Date(withdrawal.requestDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  
                  {showRejectForm === withdrawal.id ? (
                    <div className="space-y-3">
                      <Textarea
                        value={rejectReason}
                        onChange={(e) => setRejectReason(e.target.value)}
                        placeholder="Reason for rejection..."
                        className="bg-white/10 border-white/20 text-white"
                      />
                      <div className="flex space-x-2">
                        <Button
                          onClick={() => processWithdrawal(withdrawal.id, 'rejected', rejectReason)}
                          disabled={processing === withdrawal.id || !rejectReason.trim()}
                          className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                        >
                          <X className="w-4 h-4 mr-2" />
                          Confirm Reject
                        </Button>
                        <Button
                          onClick={() => {
                            setShowRejectForm(null)
                            setRejectReason('')
                          }}
                          variant="outline"
                          className="flex-1 border-white/20 text-white hover:bg-white/10"
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex space-x-2">
                      <Button
                        onClick={() => processWithdrawal(withdrawal.id, 'approved')}
                        disabled={processing === withdrawal.id}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                      >
                        <Check className="w-4 h-4 mr-2" />
                        {processing === withdrawal.id ? 'Processing...' : 'Approve'}
                      </Button>
                      <Button
                        onClick={() => setShowRejectForm(withdrawal.id)}
                        disabled={processing === withdrawal.id}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Processed Withdrawals */}
      {processedWithdrawals.length > 0 && (
        <Card className="bg-white/10 backdrop-blur-md border-white/20">
          <CardHeader>
            <CardTitle className="text-white">Recent Processed Withdrawals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {processedWithdrawals.slice(0, 10).map((withdrawal) => (
                <div
                  key={withdrawal.id}
                  className={`flex items-center justify-between p-3 rounded-lg ${
                    withdrawal.status === 'approved' ? 'bg-green-500/20' : 'bg-red-500/20'
                  }`}
                >
                  <div>
                    <p className="text-white">{withdrawal.userName}</p>
                    <p className="text-purple-200 text-sm">
                      ₨{withdrawal.amount} • {withdrawal.method.toUpperCase()}
                    </p>
                  </div>
                  <span className={`text-sm capitalize ${
                    withdrawal.status === 'approved' ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {withdrawal.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}