import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Textarea } from '../ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { CreditCard, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Withdrawal {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  method: string;
  accountDetails: string;
  status: string;
  requestDate: string;
  processedDate: string | null;
  rejectionReason: string | null;
}

interface AdminWithdrawalsProps {
  withdrawals: Withdrawal[];
  onProcessWithdrawal: (withdrawalId: string, action: string, rejectionReason?: string) => Promise<void>;
}

export function AdminWithdrawals({ withdrawals, onProcessWithdrawal }: AdminWithdrawalsProps) {
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [loading, setLoading] = useState(false);

  const handleApprove = async (withdrawal: Withdrawal) => {
    setLoading(true);
    try {
      await onProcessWithdrawal(withdrawal.id, 'approved');
      toast.success('Withdrawal approved successfully');
    } catch (error) {
      console.error('Failed to approve withdrawal:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    if (!selectedWithdrawal || !rejectionReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    setLoading(true);
    try {
      await onProcessWithdrawal(selectedWithdrawal.id, 'rejected', rejectionReason);
      toast.success('Withdrawal rejected successfully');
      setSelectedWithdrawal(null);
      setRejectionReason('');
    } catch (error) {
      console.error('Failed to reject withdrawal:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return <Clock className="w-5 h-5 text-yellow-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-500';
      case 'rejected':
        return 'bg-red-500';
      default:
        return 'bg-yellow-500';
    }
  };

  const getMethodLabel = (method: string) => {
    switch (method) {
      case 'jazzcash':
        return 'JazzCash';
      case 'easypaisa':
        return 'EasyPaisa';
      case 'bank':
        return 'Bank Transfer';
      default:
        return method;
    }
  };

  const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending');
  const processedWithdrawals = withdrawals.filter(w => w.status !== 'pending');

  return (
    <div className="space-y-6">
      {/* Pending Withdrawals */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <span>Pending Withdrawals</span>
          </CardTitle>
          <CardDescription className="text-white/70">
            Withdrawal requests awaiting your approval
          </CardDescription>
        </CardHeader>
        <CardContent>
          {pendingWithdrawals.length === 0 ? (
            <div className="text-center py-8">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
              <div className="text-white/70">No pending withdrawals</div>
              <p className="text-sm text-white/50 mt-2">All caught up!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingWithdrawals.map((withdrawal) => (
                <div
                  key={withdrawal.id}
                  className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <div>
                          <div className="font-medium">{withdrawal.userName}</div>
                          <div className="text-sm text-white/70">
                            {withdrawal.amount} PKR via {getMethodLabel(withdrawal.method)}
                          </div>
                          <div className="text-xs text-white/50">
                            Account: {withdrawal.accountDetails}
                          </div>
                          <div className="text-xs text-white/50">
                            Requested: {new Date(withdrawal.requestDate).toLocaleDateString()}
                          </div>
                        </div>
                        <Badge className={getStatusColor(withdrawal.status)}>
                          {withdrawal.status.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        size="sm"
                        onClick={() => handleApprove(withdrawal)}
                        disabled={loading}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Approve
                      </Button>
                      
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => setSelectedWithdrawal(withdrawal)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            <XCircle className="w-4 h-4 mr-2" />
                            Reject
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-gray-900 border-gray-700 text-white">
                          <DialogHeader>
                            <DialogTitle>Reject Withdrawal</DialogTitle>
                            <DialogDescription className="text-gray-300">
                              Please provide a reason for rejecting this withdrawal request
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <label className="text-sm font-medium">Rejection Reason</label>
                              <Textarea
                                value={rejectionReason}
                                onChange={(e) => setRejectionReason(e.target.value)}
                                placeholder="Explain why this withdrawal is being rejected..."
                                className="bg-gray-800 border-gray-600 text-white"
                              />
                            </div>
                          </div>
                          <DialogFooter>
                            <Button
                              onClick={handleReject}
                              disabled={loading || !rejectionReason.trim()}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              {loading ? 'Rejecting...' : 'Reject Withdrawal'}
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Processed Withdrawals */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CreditCard className="w-5 h-5" />
            <span>Withdrawal History</span>
          </CardTitle>
          <CardDescription className="text-white/70">
            Previously processed withdrawal requests
          </CardDescription>
        </CardHeader>
        <CardContent>
          {processedWithdrawals.length === 0 ? (
            <div className="text-center py-8">
              <CreditCard className="w-12 h-12 text-white/30 mx-auto mb-4" />
              <div className="text-white/70">No processed withdrawals yet</div>
            </div>
          ) : (
            <div className="space-y-4">
              {processedWithdrawals.slice(0, 10).map((withdrawal) => (
                <div
                  key={withdrawal.id}
                  className="p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(withdrawal.status)}
                      <div>
                        <div className="font-medium">{withdrawal.userName}</div>
                        <div className="text-sm text-white/70">
                          {withdrawal.amount} PKR via {getMethodLabel(withdrawal.method)}
                        </div>
                        <div className="text-xs text-white/50">
                          Processed: {withdrawal.processedDate ? new Date(withdrawal.processedDate).toLocaleDateString() : 'N/A'}
                        </div>
                        {withdrawal.status === 'rejected' && withdrawal.rejectionReason && (
                          <div className="text-xs text-red-400 mt-1">
                            Reason: {withdrawal.rejectionReason}
                          </div>
                        )}
                      </div>
                    </div>
                    <Badge className={getStatusColor(withdrawal.status)}>
                      {withdrawal.status.toUpperCase()}
                    </Badge>
                  </div>
                </div>
              ))}
              
              {processedWithdrawals.length > 10 && (
                <div className="text-center text-white/70">
                  ... and {processedWithdrawals.length - 10} more processed withdrawals
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}