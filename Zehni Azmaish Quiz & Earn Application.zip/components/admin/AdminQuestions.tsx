import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Textarea } from '../ui/textarea';
import { Badge } from '../ui/badge';
import { QUIZ_CATEGORIES, QUIZ_DIFFICULTIES } from '../../utils/constants';
import { Brain, Plus, Zap } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface Question {
  category: string;
  difficulty: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

interface AdminQuestionsProps {
  questions: Question[];
  onAddQuestion: (question: Question) => Promise<void>;
}

export function AdminQuestions({ questions, onAddQuestion }: AdminQuestionsProps) {
  const [newQuestion, setNewQuestion] = useState<Question>({
    category: '',
    difficulty: '',
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    explanation: ''
  });
  const [loading, setLoading] = useState(false);

  const handleAddQuestion = async () => {
    if (!newQuestion.category || !newQuestion.difficulty || !newQuestion.question || 
        newQuestion.options.some(opt => !opt.trim()) || !newQuestion.explanation) {
      toast.error('Please fill all fields');
      return;
    }

    setLoading(true);
    try {
      await onAddQuestion(newQuestion);
      toast.success('Question added successfully');
      setNewQuestion({
        category: '',
        difficulty: '',
        question: '',
        options: ['', '', '', ''],
        correctAnswer: 0,
        explanation: ''
      });
    } catch (error) {
      console.error('Failed to add question:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateOption = (index: number, value: string) => {
    const newOptions = [...newQuestion.options];
    newOptions[index] = value;
    setNewQuestion({ ...newQuestion, options: newOptions });
  };

  const generateAIQuestions = () => {
    toast.info('AI question generation would be implemented with Google Gemini API here');
  };

  return (
    <div className="space-y-6">
      {/* Add Question Form */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Plus className="w-5 h-5" />
            <span>Add New Question</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Category</Label>
              <Select 
                value={newQuestion.category} 
                onValueChange={(value) => setNewQuestion({ ...newQuestion, category: value })}
              >
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {QUIZ_CATEGORIES.map((cat) => (
                    <SelectItem key={cat.name} value={cat.name} className="text-white">
                      {cat.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Difficulty</Label>
              <Select 
                value={newQuestion.difficulty} 
                onValueChange={(value) => setNewQuestion({ ...newQuestion, difficulty: value })}
              >
                <SelectTrigger className="bg-white/10 border-white/20 text-white">
                  <SelectValue placeholder="Select difficulty" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {QUIZ_DIFFICULTIES.map((diff) => (
                    <SelectItem key={diff} value={diff} className="text-white">
                      {diff}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Question</Label>
            <Textarea
              value={newQuestion.question}
              onChange={(e) => setNewQuestion({ ...newQuestion, question: e.target.value })}
              placeholder="Enter the question"
              className="bg-white/10 border-white/20 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label>Options</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {newQuestion.options.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <span className="text-sm font-medium">{String.fromCharCode(65 + index)}.</span>
                  <Input
                    value={option}
                    onChange={(e) => updateOption(index, e.target.value)}
                    placeholder={`Option ${String.fromCharCode(65 + index)}`}
                    className="bg-white/10 border-white/20 text-white"
                  />
                  <Button
                    size="sm"
                    variant={newQuestion.correctAnswer === index ? "default" : "outline"}
                    onClick={() => setNewQuestion({ ...newQuestion, correctAnswer: index })}
                    className={
                      newQuestion.correctAnswer === index 
                        ? "bg-green-600 hover:bg-green-700" 
                        : "bg-white/10 border-white/20 text-white hover:bg-white/20"
                    }
                  >
                    Correct
                  </Button>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Explanation</Label>
            <Textarea
              value={newQuestion.explanation}
              onChange={(e) => setNewQuestion({ ...newQuestion, explanation: e.target.value })}
              placeholder="Explain why this is the correct answer"
              className="bg-white/10 border-white/20 text-white"
            />
          </div>

          <div className="flex space-x-4">
            <Button
              onClick={handleAddQuestion}
              disabled={loading}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              {loading ? 'Adding...' : 'Add Question'}
            </Button>
            <Button
              onClick={generateAIQuestions}
              variant="outline"
              className="bg-purple-600/20 border-purple-500/50 text-purple-300 hover:bg-purple-600/30"
            >
              <Zap className="w-4 h-4 mr-2" />
              Generate with AI
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Questions List */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Brain className="w-5 h-5" />
            <span>Question Database</span>
          </CardTitle>
          <CardDescription className="text-white/70">
            Manage existing quiz questions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {questions.length === 0 ? (
            <div className="text-center py-8">
              <Brain className="w-12 h-12 text-white/30 mx-auto mb-4" />
              <div className="text-white/70">No questions found</div>
              <p className="text-sm text-white/50 mt-2">Add your first question above</p>
            </div>
          ) : (
            <div className="space-y-4">
              {questions.slice(0, 10).map((q, index) => (
                <div
                  key={index}
                  className="p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="font-medium mb-2">{q.question}</div>
                      <div className="flex items-center space-x-2 mb-2">
                        <Badge className="bg-blue-500">{q.category}</Badge>
                        <Badge className="bg-purple-500">{q.difficulty}</Badge>
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-3">
                    {q.options.map((option, optIndex) => (
                      <div
                        key={optIndex}
                        className={`p-2 rounded text-sm ${
                          q.correctAnswer === optIndex 
                            ? 'bg-green-500/20 border border-green-500/50' 
                            : 'bg-white/5'
                        }`}
                      >
                        <span className="font-medium">{String.fromCharCode(65 + optIndex)}.</span> {option}
                      </div>
                    ))}
                  </div>
                  
                  {q.explanation && (
                    <div className="text-sm text-white/70 bg-white/5 p-2 rounded">
                      <strong>Explanation:</strong> {q.explanation}
                    </div>
                  )}
                </div>
              ))}
              
              {questions.length > 10 && (
                <div className="text-center text-white/70">
                  ... and {questions.length - 10} more questions
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}