import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { 
  Trophy, 
  Medal, 
  Award, 
  Crown,
  TrendingUp,
  Users,
  Star
} from 'lucide-react';

interface LeaderboardProps {
  user: any;
}

export function Leaderboard({ user }: LeaderboardProps) {
  const [leaderboard, setLeaderboard] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userRank, setUserRank] = useState(null);

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const loadLeaderboard = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/leaderboard`,
        {
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      const data = await response.json();
      
      if (response.ok) {
        setLeaderboard(data.leaderboard || []);
        
        // Find user's rank
        const userIndex = data.leaderboard.findIndex(u => u.id === user.id);
        if (userIndex !== -1) {
          setUserRank(userIndex + 1);
        }
      }
    } catch (error) {
      console.error('Failed to load leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (position) => {
    switch (position) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-400" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-300" />;
      case 3:
        return <Award className="w-6 h-6 text-orange-400" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-white font-bold">#{position}</span>;
    }
  };

  const getRankBadgeColor = (position) => {
    switch (position) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600';
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500';
      case 3:
        return 'bg-gradient-to-r from-orange-400 to-orange-600';
      default:
        return 'bg-white/20';
    }
  };

  const getAvatarColor = (name) => {
    const colors = [
      'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500',
      'bg-purple-500', 'bg-pink-500', 'bg-indigo-500', 'bg-teal-500'
    ];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-white text-xl">Loading leaderboard...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">🏆 Leaderboard</h1>
        <p className="text-white/70">Top performers in Zehni Azmaish</p>
      </div>

      {/* User's Rank */}
      {userRank && (
        <Card className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 backdrop-blur-md border-purple-500/30 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Star className="w-6 h-6 text-yellow-400" />
                  <span className="text-lg font-bold">Your Rank</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold">#{userRank}</div>
                <div className="text-sm text-white/70">
                  {user?.user_metadata?.points || 0} points
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Top 3 Podium */}
      {leaderboard.length >= 3 && (
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardHeader>
            <CardTitle className="text-center">🏆 Top 3 Champions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center items-end space-x-4">
              {/* 2nd Place */}
              <div className="flex flex-col items-center">
                <div className="bg-gradient-to-r from-gray-300 to-gray-500 rounded-full p-4 mb-3">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className={`${getAvatarColor(leaderboard[1]?.name)} text-white font-bold`}>
                      {leaderboard[1]?.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="text-center">
                  <div className="font-bold text-lg">{leaderboard[1]?.name}</div>
                  <div className="text-sm text-white/70">{leaderboard[1]?.points} pts</div>
                  <Badge className="bg-gradient-to-r from-gray-300 to-gray-500 text-gray-900 mt-2">
                    2nd Place
                  </Badge>
                </div>
              </div>

              {/* 1st Place */}
              <div className="flex flex-col items-center transform scale-110">
                <div className="bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full p-6 mb-3 relative">
                  <Crown className="w-6 h-6 text-yellow-900 absolute -top-2 left-1/2 transform -translate-x-1/2" />
                  <Avatar className="w-16 h-16">
                    <AvatarFallback className={`${getAvatarColor(leaderboard[0]?.name)} text-white font-bold text-xl`}>
                      {leaderboard[0]?.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="text-center">
                  <div className="font-bold text-xl">{leaderboard[0]?.name}</div>
                  <div className="text-sm text-white/70">{leaderboard[0]?.points} pts</div>
                  <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-yellow-900 mt-2">
                    🏆 Champion
                  </Badge>
                </div>
              </div>

              {/* 3rd Place */}
              <div className="flex flex-col items-center">
                <div className="bg-gradient-to-r from-orange-400 to-orange-600 rounded-full p-4 mb-3">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className={`${getAvatarColor(leaderboard[2]?.name)} text-white font-bold`}>
                      {leaderboard[2]?.name.charAt(0).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="text-center">
                  <div className="font-bold text-lg">{leaderboard[2]?.name}</div>
                  <div className="text-sm text-white/70">{leaderboard[2]?.points} pts</div>
                  <Badge className="bg-gradient-to-r from-orange-400 to-orange-600 text-orange-900 mt-2">
                    3rd Place
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Complete Leaderboard */}
      <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="w-5 h-5" />
            <span>Complete Rankings</span>
          </CardTitle>
          <CardDescription className="text-white/70">
            All players ranked by total points earned
          </CardDescription>
        </CardHeader>
        <CardContent>
          {leaderboard.length === 0 ? (
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-white/30 mx-auto mb-4" />
              <div className="text-white/70">No players yet</div>
              <p className="text-sm text-white/50 mt-2">Be the first to earn points!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {leaderboard.map((player, index) => (
                <div
                  key={player.id}
                  className={`
                    p-4 rounded-lg border transition-colors
                    ${player.id === user.id 
                      ? 'bg-purple-500/20 border-purple-500/50' 
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-3">
                        {getRankIcon(index + 1)}
                        <Avatar className="w-10 h-10">
                          <AvatarFallback className={`${getAvatarColor(player.name)} text-white font-bold`}>
                            {player.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium flex items-center space-x-2">
                            <span>{player.name}</span>
                            {player.id === user.id && (
                              <Badge variant="secondary" className="bg-purple-500 text-white text-xs">
                                You
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-white/70">
                            Rank #{index + 1}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-lg">{player.points.toLocaleString()}</div>
                      <div className="text-sm text-white/70">points</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <TrendingUp className="w-8 h-8 text-blue-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">{leaderboard.length}</div>
            <div className="text-sm text-white/70">Total Players</div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">
              {leaderboard.length > 0 ? leaderboard[0]?.points.toLocaleString() : 0}
            </div>
            <div className="text-sm text-white/70">Highest Score</div>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-md border-white/20 text-white">
          <CardContent className="p-6 text-center">
            <Trophy className="w-8 h-8 text-purple-400 mx-auto mb-2" />
            <div className="text-2xl font-bold">
              {Math.round(leaderboard.reduce((sum, p) => sum + p.points, 0) / leaderboard.length) || 0}
            </div>
            <div className="text-sm text-white/70">Average Score</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}