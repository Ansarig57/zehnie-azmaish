import React, { useState, useEffect } from 'react';
import { supabase } from './utils/supabase/client';
import { Login } from './components/Login';
import { Dashboard } from './components/Dashboard';
import { Quiz } from './components/Quiz';
import { Wallet } from './components/Wallet';
import { Leaderboard } from './components/Leaderboard';
import { Profile } from './components/Profile';
import { AdminPanel } from './components/AdminPanel';
import { Sidebar } from './components/Sidebar';
import { toast, Toaster } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from './utils/supabase/info';

interface User {
  id: string;
  email: string;
  user_metadata: {
    name: string;
    phone?: string;
    role: string;
    points: number;
    earnings: number;
    loginStreak: number;
    lastLogin: string | null;
    avatar?: string;
  };
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    checkSession();
    initializeApp();
  }, []);

  const checkSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user as User);
        checkDailyLogin(session.access_token);
      }
    } catch (error) {
      console.error('Session check error:', error);
    } finally {
      setLoading(false);
    }
  };

  const initializeApp = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/init`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (!response.ok) {
        console.error('App initialization failed');
      }
    } catch (error) {
      console.error('App initialization error:', error);
    }
  };

  const checkDailyLogin = async (accessToken: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/daily-login`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await response.json();
      if (data.bonus > 0) {
        toast.success(`Daily login bonus: ${data.bonus} points! Streak: ${data.streak} days`);
      }
    } catch (error) {
      console.error('Daily login check error:', error);
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        toast.error(error.message);
        return false;
      }

      if (session?.user) {
        setUser(session.user as User);
        checkDailyLogin(session.access_token);
        toast.success('Login successful!');
        return true;
      }
    } catch (error) {
      console.error('Login error:', error);
      toast.error('Login failed. Please try again.');
      return false;
    }
  };

  const handleSignup = async (email: string, password: string, name: string, phone: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-c7e72f01/signup`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password, name, phone })
      });

      const data = await response.json();
      
      if (!response.ok) {
        toast.error(data.error || 'Signup failed');
        return false;
      }

      toast.success('Account created successfully! Please login.');
      return true;
    } catch (error) {
      console.error('Signup error:', error);
      toast.error('Signup failed. Please try again.');
      return false;
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setCurrentPage('dashboard');
      setSidebarOpen(false);
      toast.success('Logged out successfully');
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('Logout failed');
    }
  };

  const isAdmin = user?.user_metadata?.role === 'admin';

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <Login onLogin={handleLogin} onSignup={handleSignup} />
        <Toaster position="top-center" richColors />
      </>
    );
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard user={user} onNavigate={setCurrentPage} />;
      case 'quiz':
        return <Quiz user={user} onNavigate={setCurrentPage} />;
      case 'wallet':
        return <Wallet user={user} />;
      case 'leaderboard':
        return <Leaderboard user={user} />;
      case 'profile':
        return <Profile user={user} onLogout={handleLogout} />;
      case 'admin':
        return isAdmin ? <AdminPanel user={user} /> : <Dashboard user={user} onNavigate={setCurrentPage} />;
      default:
        return <Dashboard user={user} onNavigate={setCurrentPage} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <Sidebar 
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        isAdmin={isAdmin}
        onLogout={handleLogout}
      />
      
      <div className="lg:ml-64">
        <header className="bg-white/10 backdrop-blur-md border-b border-white/20 p-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden text-white p-2 rounded-lg hover:bg-white/10"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            
            <h1 className="text-2xl font-bold text-white">Zehni Azmaish</h1>
            
            <div className="flex items-center space-x-4">
              <div className="text-white text-right">
                <div className="text-sm opacity-75">Points</div>
                <div className="font-bold">{user?.user_metadata?.points || 0}</div>
              </div>
              <div className="text-white text-right">
                <div className="text-sm opacity-75">PKR</div>
                <div className="font-bold">{user?.user_metadata?.earnings || 0}</div>
              </div>
            </div>
          </div>
        </header>

        <main className="p-4">
          {renderPage()}
        </main>
      </div>

      <Toaster position="top-center" richColors />
    </div>
  );
}