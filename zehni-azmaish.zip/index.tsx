import { GoogleGenAI, Type } from "@google/genai";

// --- TYPE DEFINITIONS ---
interface User {
    id: string;
    name: string;
    email: string;
    phone?: string;
    password?: string; // In a real app, this would be a hash
    points: number;
    totalWithdrawn: number;
    isAdmin: boolean;
    signupMethod: 'Email' | 'Phone';
    avatar: string; // Font Awesome class name
    lastLoginDate: string; // YYYY-MM-DD
    loginStreak: number;
    lifelines: {
        fiftyFifty: number;
    };
    unlockedLevels: { [key: string]: string }; // e.g., { generalKnowledge: 'medium' }
    achievements: string[]; // Array of achievement IDs
    quizzesPlayed: number;
}

interface Question {
    id: string;
    category: string;
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
}

interface Withdrawal {
    id: string;
    userId: string;
    userEmail: string;
    amount: number; // in PKR
    points: number;
    method: string;
    details: string;
    date: string;
    status: 'pending' | 'approved' | 'rejected';
    rejectionReason?: string;
}

interface Quiz {
    questions: Question[];
    currentQuestionIndex: number;
    score: number;
    correctAnswers: number;
    category: string;
    level: string;
}

interface AchievementDefinition {
    id: string;
    name: string;
    description: string;
    icon: string;
    check: (user: User, quiz?: Quiz) => boolean;
}


// --- APP STATE ---
let currentUser: User | null = null;
let currentQuiz: Quiz | null = null;
let quizTimer: number | null = null;
const QUIZ_TIME_LIMIT = 15; // seconds per question

// --- CONSTANTS ---
const avatars = [
    'fas fa-user-secret', 'fas fa-user-astronaut', 'fas fa-user-ninja', 'fas fa-user-tie',
    'fas fa-cat', 'fas fa-dog', 'fas fa-dragon', 'fas fa-robot',
    'fas fa-ghost', 'fas fa-hippo', 'fas fa-otter', 'fas fa-motorcycle'
];
const LEVEL_ORDER = ['beginner', 'medium', 'hard', 'expert'];
const UNLOCK_THRESHOLD = 70; // % accuracy to unlock next level

// --- AI Initialization ---
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

// --- DATABASE (LocalStorage Wrapper) ---
const DB = {
    get: (key: string) => {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error(`Error getting data from localStorage for key: ${key}`, error);
            return null;
        }
    },
    set: (key: string, value: any) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error(`Error setting data to localStorage for key: ${key}`, error);
        }
    },
    init: () => {
        if (!DB.get('users')) {
            const defaultUser: User = {
                id: 'user-default',
                name: 'Test User',
                email: 'user@gmail.com',
                password: 'user@123',
                phone: '03001234567',
                points: 2500,
                totalWithdrawn: 50,
                isAdmin: false,
                signupMethod: 'Email',
                avatar: 'fas fa-user-ninja',
                lastLoginDate: '1970-01-01',
                loginStreak: 0,
                lifelines: { fiftyFifty: 3 },
                unlockedLevels: {
                    generalKnowledge: 'medium',
                },
                achievements: ['novice', 'apprentice'],
                quizzesPlayed: 15
            };
            DB.set('users', [defaultUser]);
        }
        if (!DB.get('withdrawals')) DB.set('withdrawals', []);
        if (!DB.get('questions')) {
             const initialQuestions = {
                generalKnowledge: {
                    beginner: [
                        { id: 'gkb1', category: 'generalKnowledge', question: 'What is the capital of Pakistan?', options: ['Karachi', 'Lahore', 'Islamabad', 'Peshawar'], correctIndex: 2, explanation: 'Islamabad has been the capital of Pakistan since 1967.' },
                        { id: 'gkb2', category: 'generalKnowledge', question: 'Which is the largest planet in our solar system?', options: ['Earth', 'Jupiter', 'Saturn', 'Mars'], correctIndex: 1, explanation: 'Jupiter is the largest planet in our solar system by a large margin.' },
                        { id: 'gkb3', category: 'generalKnowledge', question: 'How many continents are there in the world?', options: ['5', '6', '7', '8'], correctIndex: 2, explanation: 'There are seven continents: Asia, Africa, North America, South America, Antarctica, Europe, and Australia.' },
                    ],
                    medium: [
                        { id: 'gkm1', category: 'generalKnowledge', question: 'What is the currency of Japan?', options: ['Yuan', 'Yen', 'Won', 'Baht'], correctIndex: 1, explanation: 'The Japanese Yen (JPY) is the official currency of Japan.' },
                        { id: 'gkm2', category: 'generalKnowledge', question: 'Who wrote the famous play "Romeo and Juliet"?', options: ['Charles Dickens', 'Jane Austen', 'William Shakespeare', 'Mark Twain'], correctIndex: 2, explanation: 'William Shakespeare, the famous English playwright, wrote "Romeo and Juliet".' }
                    ],
                    hard: [
                         { id: 'gkh1', category: 'generalKnowledge', question: 'Which element has the highest melting point?', options: ['Tungsten', 'Carbon', 'Osmium', 'Platinum'], correctIndex: 0, explanation: 'Tungsten has the highest melting point of all metallic elements, at 3,422 degrees Celsius.' }
                    ],
                    expert: [
                        { id: 'gke1', category: 'generalKnowledge', question: 'Which country is known as the Land of the Rising Sun?', options: ['China', 'Japan', 'South Korea', 'Thailand'], correctIndex: 1, explanation: 'Japan is often called the "Land of the Rising Sun" because the sun rises in the east.' }
                    ]
                },
                islamic: {
                    beginner: [
                        { id: 'isb1', category: 'islamic', question: 'How many chapters (Surahs) are there in the Holy Quran?', options: ['114', '115', '113', '116'], correctIndex: 0, explanation: 'The Holy Quran contains 114 chapters (Surahs).' },
                        { id: 'isb2', category: 'islamic', question: 'What is the first month of the Islamic calendar?', options: ['Ramadan', 'Safar', 'Muharram', 'Rabi al-Awwal'], correctIndex: 2, explanation: 'Muharram is the first month of the Islamic Hijri calendar.' },
                    ],
                    medium: [
                        { id: 'ism1', category: 'islamic', question: 'In which cave did Prophet Muhammad (PBUH) receive his first revelation?', options: ['Cave of Hira', 'Cave of Thawr', 'Cave of Uhud', 'Cave of Safa'], correctIndex: 0, explanation: 'The first revelation was received in the Cave of Hira (Ghar-e-Hira) on Jabal al-Nour.' }
                    ],
                    hard: [
                        { id: 'ish1', category: 'islamic', question: 'Who was the first person to accept Islam from the children?', options: ['Hazrat Abu Bakr (RA)', 'Hazrat Zayd ibn Harithah (RA)', 'Hazrat Ali ibn Abi Talib (RA)', 'Hazrat Bilal (RA)'], correctIndex: 2, explanation: 'Hazrat Ali ibn Abi Talib (RA) was the first child to accept Islam.' }
                    ],
                    expert: [
                        { id: 'ise1', category: 'islamic', question: 'Which prophet is known as "Khalilullah" (Friend of Allah)?', options: ['Prophet Musa (AS)', 'Prophet Isa (AS)', 'Prophet Ibrahim (AS)', 'Prophet Muhammad (PBUH)'], correctIndex: 2, explanation: 'Prophet Ibrahim (AS) is known by the title Khalilullah.' }
                    ]
                },
                sports: {
                    beginner: [
                        { id: 'spb1', category: 'sports', question: 'Which country won the first cricket world cup?', options: ['Australia', 'England', 'West Indies', 'India'], correctIndex: 2, explanation: 'West Indies won the first cricket world cup in 1975.' }
                    ]
                },
                science: {
                     beginner: [
                        { id: 'scb1', category: 'science', question: 'What is the chemical symbol for water?', options: ['H2O', 'CO2', 'O2', 'NaCl'], correctIndex: 0, explanation: 'H2O represents two hydrogen atoms and one oxygen atom.' }
                    ]
                },
                history: {
                    beginner: [
                        { id: 'hib1', category: 'history', question: 'When did Pakistan get its independence?', options: ['1945', '1947', '1950', '1971'], correctIndex: 1, explanation: 'Pakistan became independent on August 14, 1947.' }
                    ]
                }
            };
            DB.set('questions', initialQuestions);
        }
    }
};

// --- ACHIEVEMENTS ---
const ACHIEVEMENT_DEFINITIONS: AchievementDefinition[] = [
    { id: 'novice', name: 'Quiz Novice', description: 'Complete your first quiz.', icon: 'fas fa-play-circle', check: (user) => user.quizzesPlayed >= 1 },
    { id: 'apprentice', name: 'Quiz Apprentice', description: 'Complete 10 quizzes.', icon: 'fas fa-graduation-cap', check: (user) => user.quizzesPlayed >= 10 },
    { id: 'veteran', name: 'Quiz Veteran', description: 'Complete 50 quizzes.', icon: 'fas fa-star', check: (user) => user.quizzesPlayed >= 50 },
    { id: 'perfect_score', name: 'Perfectionist', description: 'Get a perfect score on any quiz.', icon: 'fas fa-bullseye', check: (user, quiz) => !!quiz && quiz.correctAnswers === quiz.questions.length && quiz.questions.length > 0 },
    { id: 'streaker', name: 'Streaker', description: 'Log in for 7 days in a row.', icon: 'fas fa-fire', check: (user) => user.loginStreak >= 7 },
    { id: 'high_roller', name: 'High Roller', description: 'Earn a total of 10,000 points.', icon: 'fas fa-gem', check: (user) => user.points >= 10000 },
    { id: 'master_general', name: 'Generalist', description: 'Master the General Knowledge category.', icon: 'fas fa-globe-asia', check: (user) => user.unlockedLevels?.generalKnowledge === 'expert' },
    { id: 'master_islamic', name: 'Islamic Scholar', description: 'Master the Islamic Knowledge category.', icon: 'fas fa-mosque', check: (user) => user.unlockedLevels?.islamic === 'expert' }
];


// --- DOM ELEMENT GETTERS ---
const getEl = <T extends HTMLElement>(id: string): T => document.getElementById(id) as T;

// --- UTILITY FUNCTIONS ---
function showNotification(message: string, type: 'success' | 'error' | 'info' = 'info') {
    const notification = getEl('notification');
    notification.textContent = message;
    notification.className = `notification show ${type}`;
    setTimeout(() => notification.classList.remove('show'), 3000);
}

function showModal(modalId: string) { getEl(modalId).classList.add('active'); }
function closeModal(modalId: string) { getEl(modalId).classList.remove('active'); }

function startLoading(btn: HTMLButtonElement) {
    btn.disabled = true;
    const spinner = btn.querySelector<HTMLElement>('.spinner');
    if (spinner) spinner.style.display = 'inline-block';
}

function stopLoading(btn: HTMLButtonElement) {
    btn.disabled = false;
    const spinner = btn.querySelector<HTMLElement>('.spinner');
    if (spinner) spinner.style.display = 'none';
}

function getCategoryName(key: string): string {
    const categoryMeta = getCategoryMeta();
    return categoryMeta[key]?.name || key;
}

function getCategoryMeta() {
    return {
        generalKnowledge: { icon: 'fas fa-globe-asia', desc: 'Broad topics from around the world.', name: 'General Knowledge' },
        islamic: { icon: 'fas fa-mosque', desc: 'Questions about Islamic history and faith.', name: 'Islamic Quiz' },
        sports: { icon: 'fas fa-football-ball', desc: 'Test your knowledge of popular sports.', name: 'Sports' },
        science: { icon: 'fas fa-flask', desc: 'From biology to physics, challenge yourself.', name: 'Science' },
        history: { icon: 'fas fa-landmark', desc: 'Explore events that shaped our past.', name: 'History' },
    };
}

// --- AUTHENTICATION & APP ROUTING ---
function switchAppView(view: 'auth' | 'user' | 'admin') {
    getEl('authScreen').style.display = view === 'auth' ? 'block' : 'none';
    getEl('userApp').style.display = view === 'user' ? 'block' : 'none';
    getEl('adminApp').style.display = view === 'admin' ? 'block' : 'none';

    if (view === 'user' && currentUser) {
        renderUserApp();
    } else if (view === 'admin') {
        renderAdminDashboard();
    }
}

function showAuthTab(tabName: string) {
    getEl('loginForm').style.display = tabName === 'login' ? 'block' : 'none';
    getEl('signupForm').style.display = tabName === 'signup' ? 'block' : 'none';
    getEl('phoneLoginForm').style.display = tabName === 'phone' ? 'block' : 'none';
    
    getEl('loginTabBtn').classList.toggle('btn-secondary', tabName === 'login' || tabName === 'phone');
    getEl('signupTabBtn').classList.toggle('btn-secondary', tabName === 'signup');
}

function checkDailyBonus(user: User) {
    const today = new Date().toISOString().split('T')[0];
    const lastLogin = user.lastLoginDate || '1970-01-01';

    if (today === lastLogin) return; // Already claimed or logged in today

    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    let newStreak = user.loginStreak || 0;

    if (lastLogin === yesterday) {
        newStreak++;
    } else {
        newStreak = 1; // Reset if not consecutive
    }

    const bonusPoints = 50 + (newStreak * 10);
    
    user.points += bonusPoints;
    user.loginStreak = newStreak;
    user.lastLoginDate = today;

    checkAndAwardAchievements(user); // Check for login-based achievements

    const users: User[] = DB.get('users');
    const userIndex = users.findIndex((u:User) => u.id === user.id);
    if(userIndex !== -1) {
        users[userIndex] = user;
        DB.set('users', users);
    }
    
    // Show modal
    getEl('bonusStreak').textContent = `Day ${newStreak} Streak!`;
    getEl('bonusPoints').textContent = `+${bonusPoints} Points`;
    showModal('dailyBonusModal');
}

function ensureUserHasNewProperties(user: User) {
    let updated = false;
    if (!user.hasOwnProperty('avatar')) { user.avatar = 'fas fa-user-secret'; updated = true; }
    if (!user.hasOwnProperty('lastLoginDate')) { user.lastLoginDate = '1970-01-01'; updated = true; }
    if (!user.hasOwnProperty('loginStreak')) { user.loginStreak = 0; updated = true; }
    if (!user.hasOwnProperty('lifelines')) { user.lifelines = { fiftyFifty: 1 }; updated = true; }
    if (!user.hasOwnProperty('unlockedLevels')) { user.unlockedLevels = {}; updated = true; }
    if (!user.hasOwnProperty('achievements')) { user.achievements = []; updated = true; }
    if (!user.hasOwnProperty('quizzesPlayed')) { user.quizzesPlayed = 0; updated = true; }


    if (updated) {
        const users: User[] = DB.get('users');
        const userIndex = users.findIndex(u => u.id === user.id);
        if (userIndex !== -1) {
            users[userIndex] = user;
            DB.set('users', users);
        }
    }
}

function handleLogin(e: Event) {
    e.preventDefault();
    const identifier = getEl<HTMLInputElement>('loginIdentifier').value.trim().toLowerCase();
    const password = getEl<HTMLInputElement>('loginPassword').value;

    if (identifier === 'admin@gmail.com' && password === 'admin@123') {
        currentUser = { id: 'admin', name: 'Admin', email: 'admin@gmail.com', points: 0, totalWithdrawn: 0, isAdmin: true, signupMethod: 'Email', avatar: 'fas fa-user-shield', lastLoginDate: '', loginStreak: 0, lifelines: { fiftyFifty: 0 }, unlockedLevels: {}, achievements: [], quizzesPlayed: 0 };
        showNotification('Admin login successful!', 'success');
        switchAppView('admin');
        return;
    }

    const users: User[] = DB.get('users');
    const foundUser = users.find(u => (u.email?.toLowerCase() === identifier || u.phone === identifier) && u.password === password);

    if (foundUser) {
        currentUser = foundUser;
        ensureUserHasNewProperties(currentUser);
        checkDailyBonus(currentUser);
        showNotification(`Welcome back, ${currentUser.name}!`, 'success');
        switchAppView('user');
    } else {
        showNotification('Invalid credentials. Please try again.', 'error');
    }
}

function handlePhoneLogin(e: Event) {
    e.preventDefault();
    const phone = getEl<HTMLInputElement>('phoneInput').value.trim();
    if (!phone) {
        showNotification('Please enter a phone number.', 'error');
        return;
    }

    const users: User[] = DB.get('users');
    const foundUser = users.find(u => u.phone === phone);

    if (foundUser) {
        currentUser = foundUser;
        ensureUserHasNewProperties(currentUser);
        checkDailyBonus(currentUser);
        showNotification(`Welcome back, ${currentUser.name}!`, 'success');
        switchAppView('user');
    } else {
        showNotification('No account found with this phone number.', 'error');
    }
}

function handleSignUp(e: Event) {
    e.preventDefault();
    const name = getEl<HTMLInputElement>('signupName').value.trim();
    const email = getEl<HTMLInputElement>('signupEmail').value.trim().toLowerCase();
    const phone = getEl<HTMLInputElement>('signupPhone').value.trim();
    const password = getEl<HTMLInputElement>('signupPassword').value;

    if (!name || !email || !password) {
        showNotification('Please fill all required fields.', 'error');
        return;
    }

    const users: User[] = DB.get('users');
    if (users.some(u => u.email === email)) {
        showNotification('An account with this email already exists.', 'error');
        return;
    }
     if (phone && users.some(u => u.phone === phone)) {
        showNotification('An account with this phone number already exists.', 'error');
        return;
    }

    const newUser: User = {
        id: `user-${Date.now()}`,
        name,
        email,
        phone,
        password,
        points: 1050, // Welcome bonus (1000 + 50 first day)
        totalWithdrawn: 0,
        isAdmin: false,
        signupMethod: phone ? 'Phone' : 'Email',
        avatar: 'fas fa-user-secret',
        lastLoginDate: new Date().toISOString().split('T')[0],
        loginStreak: 1,
        lifelines: { fiftyFifty: 3 },
        unlockedLevels: {},
        achievements: [],
        quizzesPlayed: 0
    };

    users.push(newUser);
    DB.set('users', users);
    currentUser = newUser;
    showNotification('Account created! You received a bonus!', 'success');
    getEl('bonusStreak').textContent = `Day 1 Streak!`;
    getEl('bonusPoints').textContent = `+50 Points`;
    showModal('dailyBonusModal');
    switchAppView('user');
}

function logout() {
    currentUser = null;
    currentQuiz = null;
    if (quizTimer) clearInterval(quizTimer);
    showNotification('You have been logged out.', 'info');
    getEl<HTMLInputElement>('loginIdentifier').value = '';
    getEl<HTMLInputElement>('loginPassword').value = '';
    switchAppView('auth');
}

// --- USER APP LOGIC ---
function renderUserApp() {
    if (!currentUser) return;
    updateUserDataInUI();
    renderQuizCategories();
    renderLeaderboard();
    renderAchievementsScreen();
    showScreen('dashboard');
}

function showScreen(screenId: string) {
    document.querySelectorAll('#userApp .screen').forEach(s => (s as HTMLElement).classList.remove('active'));
    getEl(`${screenId}Screen`).classList.add('active');
    
    const isQuizScreen = screenId === 'quiz' || screenId === 'levelSelection';
    document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
    if (!isQuizScreen) {
        document.querySelector(`.nav-tab[data-screen="${screenId}"]`)?.classList.add('active');
    }

    const appHeader = getEl('appHeader');
    if(isQuizScreen) {
        appHeader.style.display = 'none';
    } else {
        appHeader.style.display = 'block';
    }

    if (screenId === 'wallet') renderWithdrawalHistory();
    if (screenId === 'dashboard') renderQuizCategories();
    if (screenId === 'achievements') renderAchievementsScreen();

}

function updateUserDataInUI() {
    if (!currentUser) return;
    const users: User[] = DB.get('users');
    const updatedUser = users.find(u => u.id === currentUser!.id);
    if(updatedUser) currentUser = updatedUser;


    const earnings = (currentUser.points / 100).toFixed(2);
    getEl('userPoints').textContent = currentUser.points.toString();
    getEl('userEarnings').textContent = `₨${earnings}`;
    getEl('walletBalance').textContent = `₨${earnings}`;
    getEl('walletPoints').textContent = currentUser.points.toString();
    getEl('walletPKR').textContent = `₨${earnings}`;
    getEl('availableBalance').textContent = earnings;
    getEl('profileName').textContent = currentUser.name;
    getEl('profileEmail').textContent = currentUser.email;
    getEl('profilePhone').textContent = currentUser.phone || 'Not provided';
    getEl('profilePoints').textContent = currentUser.points.toString();
    getEl('profileAvatar').className = `profile-avatar ${currentUser.avatar}`;
    getEl('navProfileAvatar').innerHTML = `<i class="${currentUser.avatar}"></i>`;
}

function renderQuizCategories() {
    const questionsData: { [key: string]: object } = DB.get('questions') || {};
    const categoriesContainer = getEl('quizCategories');
    categoriesContainer.innerHTML = '';

    const categoryMeta = getCategoryMeta();

    for (const categoryKey in questionsData) {
        if (!questionsData[categoryKey] || Object.keys(questionsData[categoryKey]).length === 0) continue;
        const meta = categoryMeta[categoryKey] || { icon: 'fas fa-question-circle', desc: 'A fun quiz category.', name: categoryKey };
        const card = document.createElement('div');
        card.className = 'category-card';
        card.dataset.category = categoryKey;
        card.innerHTML = `
            <i class="category-icon ${meta.icon}"></i>
            <h3 class="category-name">${meta.name}</h3>
            <p class="category-desc">${meta.desc}</p>
        `;
        categoriesContainer.appendChild(card);
    }
}

function showLevelSelection(category: string) {
    const questionsData = DB.get('questions');
    if (!currentUser || !questionsData || !questionsData[category]) return;

    showScreen('levelSelection');
    getEl('levelSelectionTitle').textContent = `Select Level: ${getCategoryName(category)}`;

    const levelGrid = getEl('levelGrid');
    levelGrid.innerHTML = '';
    
    const userHighestUnlockedLevel = currentUser.unlockedLevels?.[category] || 'beginner';
    const userHighestUnlockedLevelIndex = LEVEL_ORDER.indexOf(userHighestUnlockedLevel);

    LEVEL_ORDER.forEach((level, index) => {
        const levelQuestions = questionsData[category][level];
        if (!levelQuestions || levelQuestions.length === 0) return;

        const isLocked = index > userHighestUnlockedLevelIndex;
        const card = document.createElement('div');
        card.className = `category-card level-card ${isLocked ? 'locked' : ''}`;
        
        if (!isLocked) {
            card.dataset.category = category;
            card.dataset.level = level;
        }

        card.innerHTML = `
            ${isLocked ? '<i class="fas fa-lock lock-icon"></i>' : ''}
            <div class="level-card-difficulty">${level}</div>
            <h3 class="category-name">${getCategoryName(category)}</h3>
            <p class="category-desc">${levelQuestions.length} Questions</p>
        `;
        levelGrid.appendChild(card);
    });
}


function renderLeaderboard() {
    const users: User[] = DB.get('users');
    const sortedUsers = users.filter(u => !u.isAdmin).sort((a, b) => b.points - a.points).slice(0, 10);
    const leaderboardScreen = getEl('leaderboardScreen');
    
    let content = `<div class="card"><h2 class="card-title text-center">Top 10 Players</h2><div class="table-container"><table class="table"><thead><tr><th>Rank</th><th>Player</th><th>Points</th></tr></thead><tbody>`;
    
    sortedUsers.forEach((user, index) => {
        content += `<tr>
            <td>${index + 1}</td>
            <td><i class="${user.avatar || 'fas fa-user-secret'} leaderboard-avatar"></i> ${user.name}</td>
            <td>${user.points}</td>
        </tr>`;
    });

    content += `</tbody></table></div></div>`;
    leaderboardScreen.innerHTML = content;
}

// --- QUIZ LOGIC ---
function startQuiz(category: string, level: string) {
    const allQuestions: { [key: string]: { [key: string]: Question[] } } = DB.get('questions');
    const levelQuestions = allQuestions?.[category]?.[level];
    if (!levelQuestions || levelQuestions.length === 0) {
        showNotification('No questions available for this level yet.', 'info');
        return;
    }

    const shuffled = [...levelQuestions].sort(() => 0.5 - Math.random());
    const selectedQuestions = shuffled.slice(0, 10);

    currentQuiz = {
        questions: selectedQuestions,
        currentQuestionIndex: 0,
        score: 0,
        correctAnswers: 0,
        category: category,
        level: level,
    };
    
    showScreen('quiz');
    renderQuestion();
}

function renderQuestion() {
    if (!currentQuiz) return;
    const question = currentQuiz.questions[currentQuiz.currentQuestionIndex];
    if (!question) {
        endQuiz();
        return;
    }

    getEl('currentQuestionNum').textContent = (currentQuiz.currentQuestionIndex + 1).toString();
    getEl('totalQuestions').textContent = currentQuiz.questions.length.toString();
    getEl('currentScore').textContent = currentQuiz.score.toString();
    getEl('questionText').textContent = question.question;

    const optionsContainer = getEl('optionsContainer');
    optionsContainer.innerHTML = '';
    question.options.forEach((option, index) => {
        const optionEl = document.createElement('div');
        optionEl.className = 'option';
        optionEl.dataset.index = index.toString();
        optionEl.innerHTML = `<span class="option-letter">${String.fromCharCode(65 + index)}</span><span class="option-text">${option}</span>`;
        optionsContainer.appendChild(optionEl);
    });
    
    updateLifelineUI();
    startTimer();
}

function startTimer() {
    if (quizTimer) clearInterval(quizTimer);
    let timeLeft = QUIZ_TIME_LIMIT;
    const timerEl = getEl('timer');
    timerEl.textContent = timeLeft.toString();
    timerEl.classList.remove('warning');

    quizTimer = window.setInterval(() => {
        timeLeft--;
        timerEl.textContent = timeLeft.toString();
        if (timeLeft <= 5) timerEl.classList.add('warning');
        if (timeLeft <= 0) {
            clearInterval(quizTimer!);
            selectAnswer(-1); // Times up, no answer selected
        }
    }, 1000);
}

function selectAnswer(selectedIndex: number) {
    if (!currentQuiz) return;
    clearInterval(quizTimer!);

    const question = currentQuiz.questions[currentQuiz.currentQuestionIndex];
    const options = document.querySelectorAll('.option');
    options.forEach(o => o.classList.add('disabled')); // Disable all options

    if (selectedIndex === question.correctIndex) {
        currentQuiz.score += 10;
        currentQuiz.correctAnswers++;
        options[selectedIndex]?.classList.add('correct');
        showNotification('Correct! +10 points', 'success');
    } else {
        if(selectedIndex !== -1) options[selectedIndex]?.classList.add('incorrect');
        options[question.correctIndex]?.classList.add('correct');
        showNotification('Incorrect!', 'error');
    }
    
    updateUserDataInUI(); // Live score update if needed
    setTimeout(nextQuestion, 1500);
}

function nextQuestion() {
    if (!currentQuiz) return;
    currentQuiz.currentQuestionIndex++;
    if (currentQuiz.currentQuestionIndex < currentQuiz.questions.length) {
        renderQuestion();
    } else {
        endQuiz();
    }
}

function endQuiz() {
    if (!currentQuiz || !currentUser) return;
    
    // Update user stats
    currentUser.points += currentQuiz.score;
    currentUser.quizzesPlayed++;

    // Progression logic
    const accuracy = currentQuiz.questions.length > 0 ? (currentQuiz.correctAnswers / currentQuiz.questions.length) * 100 : 0;
    let unlockedNewLevel = false;

    if (accuracy >= UNLOCK_THRESHOLD) {
        const currentLevelIndex = LEVEL_ORDER.indexOf(currentQuiz.level);
        if (currentLevelIndex !== -1 && currentLevelIndex < LEVEL_ORDER.length - 1) {
            const nextLevel = LEVEL_ORDER[currentLevelIndex + 1];
            const userUnlockedLevelForCategory = currentUser.unlockedLevels?.[currentQuiz.category] || 'beginner';
            const userUnlockedLevelIndex = LEVEL_ORDER.indexOf(userUnlockedLevelForCategory);
            
            if (currentLevelIndex >= userUnlockedLevelIndex) {
                 currentUser.unlockedLevels[currentQuiz.category] = nextLevel;
                 unlockedNewLevel = true;
            }
        }
    }

    // Check for achievements and save user
    checkAndAwardAchievements(currentUser, currentQuiz);
    const users: User[] = DB.get('users');
    const userIndex = users.findIndex(u => u.id === currentUser!.id);
    if(userIndex !== -1) {
        users[userIndex] = currentUser;
        DB.set('users', users);
    }
    
    if (unlockedNewLevel) {
        showNotification(`Congratulations! You've unlocked the "${currentUser.unlockedLevels[currentQuiz.category]}" level for ${getCategoryName(currentQuiz.category)}!`, 'success');
    }

    updateUserDataInUI();
    
    getEl('finalScore').textContent = `+${currentQuiz.score} Points`;
    getEl('correctAnswers').textContent = `${currentQuiz.correctAnswers} / ${currentQuiz.questions.length}`;
    getEl('finalAccuracy').textContent = `${accuracy.toFixed(1)}%`;
    showModal('resultModal');
}

function quitQuiz() {
    if (quizTimer) clearInterval(quizTimer);
    currentQuiz = null;
    showScreen('dashboard');
    showNotification('Quiz abandoned.', 'info');
}

function updateLifelineUI() {
    if (!currentUser) return;
    const fiftyFiftyCount = currentUser.lifelines?.fiftyFifty || 0;
    const countEl = getEl('lifeline5050Count');
    const buttonEl = getEl<HTMLButtonElement>('lifeline5050');
    
    countEl.textContent = fiftyFiftyCount.toString();
    buttonEl.disabled = fiftyFiftyCount <= 0;
    buttonEl.style.cursor = fiftyFiftyCount <= 0 ? 'not-allowed' : 'pointer';
    buttonEl.classList.remove('used');
}

function useLifeline() {
    if (!currentQuiz || !currentUser || (currentUser.lifelines.fiftyFifty <= 0)) return;
    
    const buttonEl = getEl<HTMLButtonElement>('lifeline5050');
    if (buttonEl.classList.contains('used')) return;

    // Deduct and save
    currentUser.lifelines.fiftyFifty--;
    const users: User[] = DB.get('users');
    const userIndex = users.findIndex((u:User) => u.id === currentUser!.id);
    if (userIndex !== -1) {
        users[userIndex].lifelines.fiftyFifty = currentUser.lifelines.fiftyFifty;
        DB.set('users', users);
    }

    // Apply effect
    const question = currentQuiz.questions[currentQuiz.currentQuestionIndex];
    const options = document.querySelectorAll('.option');
    let incorrectOptionsIndexes: number[] = [];
    for (let i = 0; i < question.options.length; i++) {
        if (i !== question.correctIndex) {
            incorrectOptionsIndexes.push(i);
        }
    }
    
    incorrectOptionsIndexes.sort(() => 0.5 - Math.random());
    const optionsToHide = incorrectOptionsIndexes.slice(0, 2);

    optionsToHide.forEach(index => {
        const optionEl = options[index] as HTMLElement;
        optionEl.style.visibility = 'hidden';
        optionEl.classList.add('disabled');
    });
    
    buttonEl.classList.add('used');
    buttonEl.disabled = true;
    updateLifelineUI();
}

// --- WALLET LOGIC ---
function renderWithdrawalHistory() {
    if (!currentUser) return;
    const allWithdrawals: Withdrawal[] = DB.get('withdrawals') || [];
    const userWithdrawals = allWithdrawals.filter(w => w.userId === currentUser!.id).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    const tableBody = getEl('withdrawalHistoryContent');
    if (userWithdrawals.length === 0) {
        tableBody.innerHTML = `<tr><td colspan="5" style="text-align: center;">No withdrawal history found.</td></tr>`;
        return;
    }
    
    tableBody.innerHTML = userWithdrawals.map(w => `
        <tr>
            <td>${new Date(w.date).toLocaleDateString()}</td>
            <td>₨${w.amount}</td>
            <td>${w.method}</td>
            <td><span class="status-badge status-${w.status}">${w.status}</span></td>
            <td>${w.rejectionReason || 'N/A'}</td>
        </tr>
    `).join('');
}

function handleWithdrawalRequest(e: Event) {
    e.preventDefault();
    if (!currentUser) return;

    const amount = parseInt(getEl<HTMLInputElement>('withdrawAmount').value);
    const selectedMethodEl = document.querySelector('.withdraw-method.selected');
    const details = getEl<HTMLInputElement>('accountDetails').value.trim();

    if (isNaN(amount) || amount < 200) {
        showNotification('Minimum withdrawal amount is 200 PKR.', 'error');
        return;
    }
    if (!selectedMethodEl) {
        showNotification('Please select a withdrawal method.', 'error');
        return;
    }
    if (!details) {
        showNotification('Please provide your account details.', 'error');
        return;
    }

    const pointsToDeduct = amount * 100;
    if (currentUser.points < pointsToDeduct) {
        showNotification('You do not have enough points for this withdrawal.', 'error');
        return;
    }
    
    const users: User[] = DB.get('users');
    const userIndex = users.findIndex(u => u.id === currentUser!.id);
    if(userIndex === -1) return;

    users[userIndex].points -= pointsToDeduct;
    currentUser = users[userIndex]; // Update local state
    DB.set('users', users);

    const newWithdrawal: Withdrawal = {
        id: `wd-${Date.now()}`,
        userId: currentUser.id,
        userEmail: currentUser.email,
        amount,
        points: pointsToDeduct,
        method: selectedMethodEl.getAttribute('data-method')!,
        details,
        date: new Date().toISOString(),
        status: 'pending'
    };
    
    const withdrawals: Withdrawal[] = DB.get('withdrawals');
    withdrawals.push(newWithdrawal);
    DB.set('withdrawals', withdrawals);
    
    showNotification('Withdrawal request submitted successfully!', 'success');
    closeModal('withdrawModal');
    updateUserDataInUI();
    renderWithdrawalHistory();
}

// --- AVATAR LOGIC ---
function showAvatarModal() {
    const grid = getEl('avatarGrid');
    grid.innerHTML = avatars.map(avatarClass => `
        <div class="avatar-option" data-action="selectAvatar" data-avatar="${avatarClass}">
            <i class="${avatarClass}"></i>
        </div>
    `).join('');
    showModal('avatarModal');
}

function selectAvatar(avatarClass: string) {
    if (!currentUser) return;
    currentUser.avatar = avatarClass;

    const users: User[] = DB.get('users');
    const userIndex = users.findIndex(u => u.id === currentUser!.id);
    if(userIndex !== -1) {
        users[userIndex].avatar = avatarClass;
        DB.set('users', users);
    }
    updateUserDataInUI();
    closeModal('avatarModal');
    showNotification('Avatar updated!', 'success');
}

// --- ACHIEVEMENT LOGIC ---
function showAchievementUnlockedModal(achievement: AchievementDefinition) {
    getEl('unlockedAchievementIcon').className = `${achievement.icon} achievement-icon`;
    getEl('unlockedAchievementName').textContent = achievement.name;
    getEl('unlockedAchievementDesc').textContent = achievement.description;
    showModal('achievementUnlockedModal');
}

function checkAndAwardAchievements(user: User, quiz?: Quiz) {
    if (!user) return;
    let newAchievementAwarded = false;
    ACHIEVEMENT_DEFINITIONS.forEach(achievement => {
        // If user does not have it, and the check passes
        if (!user.achievements.includes(achievement.id) && achievement.check(user, quiz)) {
            user.achievements.push(achievement.id);
            showAchievementUnlockedModal(achievement);
            newAchievementAwarded = true;
        }
    });
    return newAchievementAwarded;
}

function renderAchievementsScreen() {
    if (!currentUser) return;
    const screen = getEl('achievementsScreen');
    let content = `<div class="card"><h2 class="card-title text-center">Your Achievements</h2><div class="achievements-grid">`;

    ACHIEVEMENT_DEFINITIONS.forEach(ach => {
        const isUnlocked = currentUser!.achievements.includes(ach.id);
        content += `
            <div class="achievement-card ${isUnlocked ? 'unlocked' : 'locked'}">
                <i class="achievement-icon ${ach.icon}"></i>
                <div class="achievement-info">
                    <h3>${ach.name}</h3>
                    <p>${ach.description}</p>
                </div>
            </div>
        `;
    });

    content += `</div></div>`;
    screen.innerHTML = content;
}


// --- ADMIN LOGIC ---
function renderAdminDashboard() {
    switchAdminTab('users');
    renderAdminUsers();
    renderAdminWithdrawals();
    renderAdminQuestions();
}

function switchAdminTab(tab: string) {
    document.querySelectorAll('.admin-content').forEach(el => el.classList.remove('active'));
    getEl(`admin${tab.charAt(0).toUpperCase() + tab.slice(1)}`).classList.add('active');
    document.querySelectorAll('.admin-nav-link').forEach(el => el.classList.remove('active'));
    document.querySelector(`.admin-nav-link[data-admin-tab="${tab}"]`)?.classList.add('active');
}

function renderAdminUsers() {
    const users: User[] = DB.get('users').filter((u:User) => !u.isAdmin);
    const tbody = getEl('adminUsersTableBody');
    tbody.innerHTML = users.map(u => `
        <tr>
            <td>
                <div><i class="${u.avatar || 'fas fa-user-secret'} leaderboard-avatar"></i> ${u.name}</div>
                <small>${u.email}</small>
            </td>
            <td>${u.signupMethod}</td>
            <td>${u.points}</td>
            <td>${u.totalWithdrawn}</td>
            <td class="table-actions">
                <button class="btn btn-secondary btn-sm" data-action="showEditUserModal" data-user-id="${u.id}">Edit</button>
            </td>
        </tr>
    `).join('');
}

function handleEditUser(e: Event) {
    e.preventDefault();
    const userId = getEl<HTMLInputElement>('editUserId').value;
    const points = parseInt(getEl<HTMLInputElement>('editUserPoints').value);
    
    const users: User[] = DB.get('users');
    const userIndex = users.findIndex(u => u.id === userId);
    if(userIndex !== -1) {
        users[userIndex].points = points;
        DB.set('users', users);
        showNotification('User updated successfully', 'success');
        closeModal('editUserModal');
        renderAdminUsers();
    }
}

function renderAdminWithdrawals() {
    const withdrawals: Withdrawal[] = DB.get('withdrawals').sort((a:Withdrawal,b:Withdrawal) => new Date(b.date).getTime() - new Date(a.date).getTime());
    const tbody = getEl('adminWithdrawalsTableBody');
    tbody.innerHTML = withdrawals.map(w => `
        <tr>
            <td>${w.userEmail}</td>
            <td>₨${w.amount}</td>
            <td><strong>${w.method}:</strong> ${w.details}</td>
            <td>${new Date(w.date).toLocaleString()}</td>
            <td><span class="status-badge status-${w.status}">${w.status}</span></td>
            <td class="table-actions">
                ${w.status === 'pending' ? `
                    <button class="btn btn-success btn-sm" data-action="approveWithdrawal" data-id="${w.id}">Approve</button>
                    <button class="btn btn-danger btn-sm" data-action="rejectWithdrawal" data-id="${w.id}">Reject</button>
                ` : 'Processed'}
            </td>
        </tr>
    `).join('');
}

function approveWithdrawal(id: string) {
    const withdrawals: Withdrawal[] = DB.get('withdrawals');
    const withdrawalIndex = withdrawals.findIndex(w => w.id === id);
    if (withdrawalIndex === -1) return;

    withdrawals[withdrawalIndex].status = 'approved';
    DB.set('withdrawals', withdrawals);

    const users: User[] = DB.get('users');
    const userIndex = users.findIndex(u => u.id === withdrawals[withdrawalIndex].userId);
    if (userIndex !== -1) {
        users[userIndex].totalWithdrawn += withdrawals[withdrawalIndex].amount;
        DB.set('users', users);
    }

    showNotification('Withdrawal approved.', 'success');
    renderAdminWithdrawals();
    renderAdminUsers();
}

function rejectWithdrawal(id: string) {
    const reason = prompt("Enter rejection reason (optional):");
    const withdrawals: Withdrawal[] = DB.get('withdrawals');
    const withdrawalIndex = withdrawals.findIndex(w => w.id === id);
    if (withdrawalIndex === -1) return;

    const withdrawal = withdrawals[withdrawalIndex];
    withdrawal.status = 'rejected';
    withdrawal.rejectionReason = reason || 'No reason provided.';
    DB.set('withdrawals', withdrawals);

    // Refund points to user
    const users: User[] = DB.get('users');
    const userIndex = users.findIndex(u => u.id === withdrawal.userId);
    if (userIndex !== -1) {
        users[userIndex].points += withdrawal.points;
        DB.set('users', users);
    }
    
    showNotification('Withdrawal rejected and points refunded.', 'success');
    renderAdminWithdrawals();
    renderAdminUsers();
}


function renderAdminQuestions() {
    const questionsByCat: { [key: string]: { [key: string]: Question[] } } = DB.get('questions');
    const tbody = getEl('adminQuestionsTableBody');
    let allQuestions: Question[] = [];
    for(const cat in questionsByCat) {
        for (const level in questionsByCat[cat]) {
            allQuestions.push(...questionsByCat[cat][level]);
        }
    }

    tbody.innerHTML = allQuestions.map(q => `
        <tr>
            <td>${getCategoryName(q.category)}</td>
            <td>${q.question.substring(0, 80)}...</td>
            <td class="table-actions">
                <button class="btn btn-danger btn-sm" data-action="deleteQuestion" data-id="${q.id}" data-category="${q.category}">Delete</button>
            </td>
        </tr>
    `).join('');
}

function deleteQuestion(id: string, category: string) {
    if (!confirm('Are you sure you want to delete this question?')) return;

    const questionsByCat: { [key: string]: { [key: string]: Question[] } } = DB.get('questions');
    if(questionsByCat[category]) {
        for (const level in questionsByCat[category]) {
            questionsByCat[category][level] = questionsByCat[category][level].filter(q => q.id !== id);
        }
        DB.set('questions', questionsByCat);
        showNotification('Question deleted.', 'success');
        renderAdminQuestions();
    }
}

function handleAddQuestion(e: Event) {
    e.preventDefault();
    const category = getEl<HTMLSelectElement>('newQuestionCategory').value;
    const question = getEl<HTMLTextAreaElement>('newQuestionText').value.trim();
    const options = [
        getEl<HTMLInputElement>('newQuestionOption1').value.trim(),
        getEl<HTMLInputElement>('newQuestionOption2').value.trim(),
        getEl<HTMLInputElement>('newQuestionOption3').value.trim(),
        getEl<HTMLInputElement>('newQuestionOption4').value.trim(),
    ];
    const correctIndex = parseInt(getEl<HTMLSelectElement>('newQuestionCorrect').value);
    const explanation = getEl<HTMLTextAreaElement>('newQuestionExplanation').value.trim();
    const level = 'beginner'; // New questions from admin are added to beginner by default

    if (!category || !question || options.some(o => !o)) {
        showNotification('Please fill all required fields.', 'error');
        return;
    }

    const newQuestion: Question = {
        id: `q-${Date.now()}`,
        category,
        question,
        options,
        correctIndex,
        explanation
    };
    
    const allQuestions: { [key: string]: { [key: string]: Question[] } } = DB.get('questions');
    if (!allQuestions[category]) {
        allQuestions[category] = { beginner: [], medium: [], hard: [], expert: [] };
    }
    if (!allQuestions[category][level]) {
        allQuestions[category][level] = [];
    }
    allQuestions[category][level].push(newQuestion);
    DB.set('questions', allQuestions);
    
    showNotification('Question added successfully!', 'success');
    getEl<HTMLFormElement>('addQuestionForm').reset();
    closeModal('addQuestionModal');
    renderAdminQuestions();
}

async function handleGenerateQuestionAI() {
    const category = getEl<HTMLSelectElement>('aiQuestionCategory').value;
    const topic = getEl<HTMLInputElement>('aiTopicInput').value.trim();
    const btn = getEl<HTMLButtonElement>('generateQuestionBtn');
    
    if (!category) {
        showNotification('Please select a category for the AI generator.', 'error');
        return;
    }

    startLoading(btn);

    const prompt = `Generate a single, high-quality, multiple-choice trivia question for a quiz app.
    Category: "${getCategoryName(category)}".
    ${topic ? `Specific Topic: "${topic}".` : ''}
    The question should be clear, concise, and verifiable.
    Provide 4 distinct options, with only one being correct.
    Also, provide a brief explanation for the correct answer.
    Return the result as a JSON object that matches the specified schema.`;

    const questionSchema = {
        type: Type.OBJECT,
        properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctIndex: { type: Type.INTEGER },
            explanation: { type: Type.STRING }
        },
        required: ['question', 'options', 'correctIndex', 'explanation']
    };

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: questionSchema,
            },
        });

        const jsonString = response.text.trim();
        const result = JSON.parse(jsonString) as Omit<Question, 'id' | 'category'>;

        if (result.options.length !== 4) {
             throw new Error("AI did not generate exactly 4 options.");
        }

        getEl<HTMLSelectElement>('newQuestionCategory').value = category;
        getEl<HTMLTextAreaElement>('newQuestionText').value = result.question;
        getEl<HTMLInputElement>('newQuestionOption1').value = result.options[0];
        getEl<HTMLInputElement>('newQuestionOption2').value = result.options[1];
        getEl<HTMLInputElement>('newQuestionOption3').value = result.options[2];
        getEl<HTMLInputElement>('newQuestionOption4').value = result.options[3];
        getEl<HTMLSelectElement>('newQuestionCorrect').value = result.correctIndex.toString();
        getEl<HTMLTextAreaElement>('newQuestionExplanation').value = result.explanation;
        showNotification('Question generated! Review and save.', 'success');
    } catch (error) {
        console.error("AI Generation Error:", error);
        showNotification('Failed to generate question with AI. Please try again.', 'error');
    } finally {
        stopLoading(btn);
    }
}

// --- INITIALIZATION & EVENT LISTENERS ---
document.addEventListener('DOMContentLoaded', () => {
    DB.init();
    
    if (currentUser) {
        switchAppView(currentUser.isAdmin ? 'admin' : 'user');
    } else {
        switchAppView('auth');
    }

    // Main event delegation
    document.body.addEventListener('click', (e) => {
        const target = e.target as HTMLElement;
        const actionTarget = target.closest('[data-action]');
        const modalCloseTarget = target.closest('.close-btn[data-modal-id], .btn[data-modal-id][data-action="closeModal"]');
        const screenTabTarget = target.closest('.nav-tab[data-screen]');
        const adminTabTarget = target.closest('.admin-nav-link[data-admin-tab]');
        const categoryCardTarget = target.closest('.category-card[data-category]:not(.level-card)');
        const levelCardTarget = target.closest('.level-card:not(.locked)');
        const optionTarget = target.closest('.option:not(.disabled)');
        const withdrawMethodTarget = target.closest('.withdraw-method');
        const authTabTarget = target.closest('.auth-tab-btn[data-auth-tab]');
        
        if (actionTarget) {
            const action = actionTarget.getAttribute('data-action');
            switch (action) {
                case 'logout': logout(); break;
                case 'showPhoneLogin': showAuthTab('phone'); break;
                case 'backToLogin': showAuthTab('login'); break;
                case 'backToCategories': showScreen('dashboard'); break;
                case 'quitQuiz': quitQuiz(); break;
                case 'skipQuestion': if(quizTimer) {clearInterval(quizTimer!); selectAnswer(-1);}; break;
                case 'playAgain': closeModal('resultModal'); if(currentQuiz) startQuiz(currentQuiz.category, currentQuiz.level); break;
                case 'goToDashboard': closeModal('resultModal'); showScreen('dashboard'); break;
                case 'showWithdrawModal': showModal('withdrawModal'); break;
                case 'useLifeline': useLifeline(); break;
                case 'showAvatarModal': showAvatarModal(); break;
                case 'selectAvatar': selectAvatar(actionTarget.getAttribute('data-avatar')!); break;
                case 'closeModal': closeModal(actionTarget.getAttribute('data-modal-id')!); break;
                case 'showAddQuestionModal':
                    const categories = Object.keys(DB.get('questions'));
                    const catOptions = categories.map(c => `<option value="${c}">${getCategoryName(c)}</option>`).join('');
                    getEl<HTMLSelectElement>('aiQuestionCategory').innerHTML = `<option value="">Select Category</option>${catOptions}`;
                    getEl<HTMLSelectElement>('newQuestionCategory').innerHTML = catOptions;
                    showModal('addQuestionModal');
                    break;
                case 'generateQuestionAI': handleGenerateQuestionAI(); break;
                case 'showEditUserModal':
                    const userId = actionTarget.getAttribute('data-user-id')!;
                    const user = DB.get('users').find((u:User) => u.id === userId);
                    if (user) {
                        getEl<HTMLInputElement>('editUserId').value = user.id;
                        getEl<HTMLInputElement>('editUserPoints').value = user.points.toString();
                        getEl('editUserName').textContent = user.name;
                        showModal('editUserModal');
                    }
                    break;
                 case 'approveWithdrawal': approveWithdrawal(actionTarget.getAttribute('data-id')!); break;
                 case 'rejectWithdrawal': rejectWithdrawal(actionTarget.getAttribute('data-id')!); break;
                 case 'deleteQuestion': deleteQuestion(actionTarget.getAttribute('data-id')!, actionTarget.getAttribute('data-category')!); break;
            }
        }
        if (modalCloseTarget) closeModal(modalCloseTarget.getAttribute('data-modal-id')!);
        if (screenTabTarget) showScreen(screenTabTarget.getAttribute('data-screen')!);
        if (adminTabTarget) switchAdminTab(adminTabTarget.getAttribute('data-admin-tab')!);
        if (categoryCardTarget) showLevelSelection(categoryCardTarget.getAttribute('data-category')!);
        if (levelCardTarget) startQuiz(levelCardTarget.getAttribute('data-category')!, levelCardTarget.getAttribute('data-level')!);
        if (optionTarget) selectAnswer(parseInt(optionTarget.getAttribute('data-index')!));
        if (withdrawMethodTarget) {
            document.querySelectorAll('.withdraw-method').forEach(el => el.classList.remove('selected'));
            withdrawMethodTarget.classList.add('selected');
            const method = withdrawMethodTarget.getAttribute('data-method');
            const detailsGroup = getEl('accountDetailsGroup');
            const detailsLabel = getEl('accountDetailsLabel');
            if (method === 'Bank') {
                detailsLabel.textContent = "Bank Name & Account Number";
            } else {
                detailsLabel.textContent = `${method} Account Number`;
            }
            detailsGroup.style.display = 'block';
        }
        if (authTabTarget) {
            showAuthTab(authTabTarget.getAttribute('data-auth-tab')!);
        }
    });

    // Form Submissions
    getEl('loginForm').addEventListener('submit', handleLogin);
    getEl('phoneLoginForm').addEventListener('submit', handlePhoneLogin);
    getEl('signupForm').addEventListener('submit', handleSignUp);
    getEl('withdrawForm').addEventListener('submit', handleWithdrawalRequest);
    getEl('addQuestionForm').addEventListener('submit', handleAddQuestion);
    getEl('editUserForm').addEventListener('submit', handleEditUser);
});